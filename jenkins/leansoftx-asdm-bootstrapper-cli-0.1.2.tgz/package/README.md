# ASDM Bootstrapper

The ASDM Bootstrapper is a command-line interface (CLI) tool designed to help developers quickly set up their development environment for ASDM (AI First System Development Methodology & Platform) projects. It automates the process of downloading and configuring the necessary library resources required for ASDM development, including toolsets, contexts, specs, skills, and workspace-scoped installs.

There is also a [INSTALL.md](https://platform.asdm.ai/_artifacts/cli/INSTALL.md) file hosted on ASDM platform to instruct AI Agent to follow and use terminal to go through the installation process automatically.

# Main Features

- List available ASDM library resources by reading from registry APIs
- Download ASDM resources into workspace
  - use `asdm toolset install {toolset-id}` command to save to `.asdm/toolsets/{toolset-id}` folder for toolsets
  - use `asdm context install {context-id}` command to save to `.asdm/contexts/{context-id}` folder for contexts
  - use `asdm spec install {spec-id}` command to save to `.asdm/specs/{spec-id}` folder for specs
  - use `asdm skill install {skill-id}` command to save to `.asdm/skills/{skill-id}` folder for skills
  - use `asdm workspace install {workspace-id}` to install toolsets/specs under `.asdm/workspaces/{workspace-id}/` (isolated per workspace; see workspace commands below)
- Update ASDM resources in your workspace

# Resource Hosting

All resources are hosted on [ASDM platform](https://platform.asdm.ai) using the [_artifacts](https://platform.asdm.ai/_artifacts) endpoint.

# Usage

To use the ASDM Bootstrapper CLI, follow these steps:

1. Install the CLI using npm or yarn:

   ```bash
   npm install -g @leansoftx/asdm-bootstrapper-cli
   ```

2. Available commands:

| Command | Description |
|---------|-------------|
| `asdm toolset list` | List all available ASDM toolsets |
| `asdm toolset install <toolset-id>` | Download and install a specific ASDM toolset |
| `asdm toolset update <toolset-id>` | Update a specific ASDM toolset to the latest version |
| `asdm toolset uninstall <toolset-id>` | Uninstall a specific ASDM toolset |
| `asdm spec list` | List all available ASDM specs |
| `asdm spec install <spec-id>` | Download and install a specific ASDM spec |
| `asdm spec update <spec-id>` | Update a specific ASDM spec to the latest version |
| `asdm spec uninstall <spec-id>` | Uninstall a specific ASDM spec |
| `asdm context list` | List all available ASDM contexts |
| `asdm context install <context-id>` | Download and install a specific ASDM context |
| `asdm context update <context-id>` | Update a specific ASDM context to the latest version |
| `asdm context uninstall <context-id>` | Uninstall a specific ASDM context |
| `asdm skill list` | List all available ASDM skills |
| `asdm skill install <skill-id>` | Download and install a specific ASDM skill |
| `asdm skill update <skill-id>` | Update a specific ASDM skill to the latest version |
| `asdm skill uninstall <skill-id>` | Uninstall a specific ASDM skill |
| `asdm workspace list <workspace-id>` | List required toolsets (and specs) for a workspace |
| `asdm workspace install <workspace-id>` | Install all toolsets/specs under `.asdm/workspaces/<id>/` and update `workspace-installs.json` |
| `asdm workspace current` | Show the active workspace id (`activeWorkspaceId` in `workspace-installs.json`) |
| `asdm workspace switch <workspace-id>` | Set active workspace; CodeBuddy defaults to this workspace |
| `asdm workspace codebuddy` | Manage CodeBuddy merge list (`list`, `add`, `remove`, `only`, `reset`) |
| `asdm workspace uninstall <workspace-id>` | Remove workspace sandbox and manifest entry |
| `asdm workspace toolset list <workspace-id>` | List required toolsets via the toolset subcommand |
| `asdm workspace toolset install <workspace-id> <toolset-id>` | Install one workspace toolset under `.asdm/workspaces/<id>/toolsets/<toolset-id>/` |
| `asdm workspace toolset update <workspace-id> <toolset-id>` | Update one workspace toolset |
| `asdm workspace toolset uninstall <workspace-id> <toolset-id>` | Uninstall one workspace toolset |
| `asdm config --set-language <CN or US>` | Set CLI language (default: CN) |
| `asdm config --set-base-url <url>` | Set default BASE_URL in user config |
| `asdm config --set-workspace-api-path <path>` | Set default workspace toolsets API path in user config |

# Folder Structure

When you use the ASDM CLI to install resources, they are stored under `.asdm` in your project. Global installs use flat paths; workspace installs use per-workspace sandboxes.

## Authentication (workspace install)

If your ASDM platform requires authentication for workspace APIs (e.g. `GET /api/workspaces/{id}/resources-manifest`), set one of these environment variables before running `asdm workspace install`:

- `ASDM_API_TOKEN` (recommended)
- `ASDM_TOKEN`
- `ASDM_BEARER_TOKEN`

Value can be either a raw token (CLI will send `Authorization: Bearer <token>`) or an explicit header value starting with `Bearer `.

```
.asdm/
├── README.md                 (index of workspace installs; maintained by workspace commands)
├── workspace-installs.json   (manifest + activeWorkspaceId + codeBuddyWorkspaceIds)
├── workspaces/
│   └── {workspace-id}/
│       ├── toolsets/{toolset-id}/
│       └── specs/{spec-id}/
├── toolsets/                 (global `asdm toolset install`)
│   └── {toolset-id}/
├── contexts/
│   └── {context-id}/
├── specs/                    (global `asdm spec install`)
│   └── {spec-id}/
└── skills/
    └── {skill-id}/
```

- **`.asdm/README.md`** — Explains layout and maps workspace ids to `workspaces/...` paths (multiple workspaces per repo).
- **`.asdm/workspace-installs.json`** — Records installed workspaces, active workspace, and CodeBuddy merge list.
- **`.asdm/workspaces/<id>/`** — Isolated toolsets/specs for `asdm workspace install` and `workspace toolset …`
- **`.asdm/toolsets/`** — Global toolsets from `asdm toolset install`
- **`.asdm/contexts/`** — Contexts from `asdm context install`
- **`.asdm/specs/`** — Global specs from `asdm spec install`
- **`.asdm/skills/`** — Skills from `asdm skill install`

Workspace-level notes:

- `asdm workspace list <workspace-id>` fetches required toolsets (and specs) from the workspace registry.
- `asdm workspace install <workspace-id>` installs every toolset and spec from the registry under `.asdm/workspaces/<id>/`, updates `workspace-installs.json`, refreshes CodeBuddy commands, and regenerates `.asdm/README.md`.
- `asdm workspace switch` / `workspace codebuddy` control which workspace(s) feed CodeBuddy slash commands.
- `asdm workspace uninstall <workspace-id>` removes the sandbox directory and the manifest entry.
- Use `asdm workspace toolset install|update|uninstall` for a single toolset under the same layout.
- Configure the workspace API via `WORKSPACE_TOOLSETS_API_PATH` (joined with `BASE_URL` unless absolute); if empty, the CLI uses `mock/workspace-toolsets.json`.
- Language and defaults live in `~/.asdm/config.json` (run `asdm config init` to create it).

# Contributing

Contributions are welcome! If you have any ideas for improvements or new features, please feel free to open an issue or submit a pull request.

# License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.
