import axios from 'axios';
import * as fs from 'fs';
import * as path from 'path';
import AdmZip from 'adm-zip';
import { ToolsetRegistry, SpecsRegistry, ContextsRegistry, SkillsRegistry, Toolset, Spec, Context, Skill } from './types';
import {
  BASE_URL,
  TOOLSET_REGISTRY_URL,
  SPECS_REGISTRY_URL,
  CONTEXTS_REGISTRY_URL,
  SKILLS_REGISTRY_URL,
  WORKSPACE_RESOURCES_MANIFEST_URL,
  USE_WORKSPACE_TOOLSETS_MOCK,
  WORKSPACE_TOOLSETS_MOCK_FILE,
  TOOLSET_BASE_URL,
  SPECS_BASE_URL,
  CONTEXTS_BASE_URL,
  SKILLS_BASE_URL,
  LOCAL_TOOLSETS_DIR,
  LOCAL_SPECS_DIR,
  LOCAL_CONTEXTS_DIR,
  LOCAL_SKILLS_DIR,
  LOCAL_ASDM_DIR,
  SKIP_SSL_VERIFICATION
} from './config';
import { getLanguage } from './user-config';
import * as https from 'https';

export function getAsdmRootPath(): string {
  return path.join(process.cwd(), LOCAL_ASDM_DIR);
}

function getCliLanguage(): 'CN' | 'US' {
  try {
    return getLanguage();
  } catch {
    return 'US';
  }
}

function normalizeWorkspaceToolsetPayload(payload: any, expectedWorkspaceId?: string): ToolsetRegistry {
  // resources-manifest API wraps data under workspaces[]
  let wsData = payload;
  if (Array.isArray(payload.workspaces) && payload.workspaces.length > 0) {
    wsData = expectedWorkspaceId
      ? payload.workspaces.find((ws: any) => `${ws.workspaceId || ''}` === expectedWorkspaceId) || payload.workspaces[0]
      : payload.workspaces[0];
  }

  const responseWorkspaceId = wsData.workspaceId;
  if (expectedWorkspaceId && responseWorkspaceId && `${responseWorkspaceId}` !== expectedWorkspaceId) {
    throw new Error(`Workspace ID mismatch: requested '${expectedWorkspaceId}', got '${responseWorkspaceId}'`);
  }

  const rawToolsets = Array.isArray(wsData.toolsets) ? wsData.toolsets : [];
  const rawSpecs = Array.isArray(wsData.specs) ? wsData.specs : [];
  const rawContexts = Array.isArray(wsData.contexts) ? wsData.contexts : [];

  const mapResource = (item: any) => ({
    id: item.id,
    name: item.name || item.id || 'Unknown',
    description: item.description ?? null,
    version: item.version ?? null,
    downloadUrl: item.downloadUrl ?? null,
    entryPoint: item.entryPoint ?? null
  });

  return {
    version: payload.version || 'unknown',
    workspaceId: responseWorkspaceId || expectedWorkspaceId,
    toolsets: rawToolsets.map(mapResource),
    specs: rawSpecs.map(mapResource),
    contexts: rawContexts.map(mapResource)
  };
}

function loadWorkspaceToolsetMockRegistry(workspaceId: string): ToolsetRegistry {
  if (!fs.existsSync(WORKSPACE_TOOLSETS_MOCK_FILE)) {
    throw new Error(`Mock file not found: ${WORKSPACE_TOOLSETS_MOCK_FILE}`);
  }
  const raw = fs.readFileSync(WORKSPACE_TOOLSETS_MOCK_FILE, 'utf8');
  const payload = JSON.parse(raw);
  return normalizeWorkspaceToolsetPayload(payload, workspaceId);
}

function buildWorkspaceRegistryUrl(registryUrl: string, workspaceId: string): string {
  const encodedWorkspaceId = encodeURIComponent(workspaceId);
  if (registryUrl.includes('{wsId}')) {
    return registryUrl.replace('{wsId}', encodedWorkspaceId);
  }
  if (registryUrl.includes(':wsId')) {
    return registryUrl.replace(':wsId', encodedWorkspaceId);
  }

  const separator = registryUrl.includes('?') ? '&' : '?';
  return `${registryUrl}${separator}workspaceId=${encodedWorkspaceId}`;
}

function getAsdmAuthHeader(): string | undefined {
  const token =
    (process.env.ASDM_API_TOKEN || '').trim() ||
    (process.env.ASDM_TOKEN || '').trim() ||
    (process.env.ASDM_BEARER_TOKEN || '').trim();
  if (!token) return undefined;
  return token.toLowerCase().startsWith('bearer ') ? token : `Bearer ${token}`;
}

// Create axios instance with SSL configuration + optional auth
const createAxiosInstance = () => {
  const authorization = getAsdmAuthHeader();
  return axios.create({
    httpsAgent: SKIP_SSL_VERIFICATION ? new https.Agent({ rejectUnauthorized: false }) : undefined,
    headers: authorization ? { Authorization: authorization } : undefined
  });
};

/**
 * Fetch the toolset registry
 */
export async function fetchToolsetRegistry(): Promise<ToolsetRegistry> {
  try {
    const axiosInstance = createAxiosInstance();
    const response = await axiosInstance.get<ToolsetRegistry>(TOOLSET_REGISTRY_URL);
    return response.data;
  } catch (error) {
    throw new Error(`Failed to fetch toolset registry: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Fetch workspace resources manifest (toolsets + specs + contexts).
 * Uses WORKSPACE_RESOURCES_MANIFEST_URL by default.
 * Pass registryUrlOverride to use a different URL or "mock".
 */
export async function fetchWorkspaceResourcesManifest(workspaceId: string, registryUrlOverride?: string): Promise<ToolsetRegistry> {
  if (registryUrlOverride === 'mock' || registryUrlOverride === 'mock://local') {
    return loadWorkspaceToolsetMockRegistry(workspaceId);
  }
  if (USE_WORKSPACE_TOOLSETS_MOCK && !registryUrlOverride) {
    return loadWorkspaceToolsetMockRegistry(workspaceId);
  }

  const registryUrl = registryUrlOverride || WORKSPACE_RESOURCES_MANIFEST_URL;
  try {
    const fullRegistryUrl = buildWorkspaceRegistryUrl(registryUrl, workspaceId);
    const axiosInstance = createAxiosInstance();
    const response = await axiosInstance.get<any>(fullRegistryUrl);
    return normalizeWorkspaceToolsetPayload(response.data || {}, workspaceId);
  } catch (error) {
    throw new Error(`Failed to fetch workspace resources manifest: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Fetch the specs registry
 */
export async function fetchSpecsRegistry(): Promise<SpecsRegistry> {
  try {
    const axiosInstance = createAxiosInstance();
    const response = await axiosInstance.get<SpecsRegistry>(SPECS_REGISTRY_URL);
    return response.data;
  } catch (error) {
    throw new Error(`Failed to fetch specs registry: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Fetch the contexts registry
 * Note: Not implemented yet, reserved for future use
 */
export async function fetchContextsRegistry(): Promise<ContextsRegistry> {
  if (!CONTEXTS_REGISTRY_URL) {
    throw new Error('Contexts registry is not implemented yet');
  }
  try {
    const axiosInstance = createAxiosInstance();
    const response = await axiosInstance.get<ContextsRegistry>(CONTEXTS_REGISTRY_URL);
    return response.data;
  } catch (error) {
    throw new Error(`Failed to fetch contexts registry: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Download a toolset ZIP file
 */
export async function downloadToolset(toolsetId: string, downloadUrl: string | null): Promise<{ buffer: Buffer; actualUrl: string }> {
  const url = downloadUrl || `${toolsetId}.zip`;
  const fullDownloadUrl = url.startsWith('http')
    ? url
    : `${TOOLSET_BASE_URL}/${url}`;
  
  try {
    const axiosInstance = createAxiosInstance();
    const response = await axiosInstance.get(fullDownloadUrl, {
      responseType: 'arraybuffer'
    });
    return { 
      buffer: Buffer.from(response.data),
      actualUrl: fullDownloadUrl
    };
  } catch (error) {
    throw new Error(`Failed to download toolset from ${fullDownloadUrl}: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Download a spec ZIP file
 */
export async function downloadSpec(specId: string, downloadUrl: string | null): Promise<{ buffer: Buffer; actualUrl: string }> {
  const url = downloadUrl || `${specId}.zip`;
  const fullDownloadUrl = url.startsWith('http')
    ? url
    : `${SPECS_BASE_URL}/${url}`;
  
  try {
    const axiosInstance = createAxiosInstance();
    const response = await axiosInstance.get(fullDownloadUrl, {
      responseType: 'arraybuffer'
    });
    return { 
      buffer: Buffer.from(response.data),
      actualUrl: fullDownloadUrl
    };
  } catch (error) {
    throw new Error(`Failed to download spec from ${fullDownloadUrl}: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Download a context ZIP file
 */
export async function downloadContext(contextId: string, downloadUrl: string | null): Promise<{ buffer: Buffer; actualUrl: string }> {
  const url = downloadUrl || `${contextId}.zip`;
  const fullDownloadUrl = url.startsWith('http')
    ? url
    : `${CONTEXTS_BASE_URL}/${url}`;
  
  try {
    const axiosInstance = createAxiosInstance();
    const response = await axiosInstance.get(fullDownloadUrl, {
      responseType: 'arraybuffer'
    });
    return { 
      buffer: Buffer.from(response.data),
      actualUrl: fullDownloadUrl
    };
  } catch (error) {
    throw new Error(`Failed to download context from ${fullDownloadUrl}: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Fetch latest context results for a workspace.
 * Returns an array of { contextId, contextName, fileName, fileContent }.
 */
export async function fetchLatestContextResults(workspaceId: string): Promise<{ contextId: string; contextName: string; fileName: string; fileContent: string }[]> {
  const url = `${BASE_URL}/api/library/workspaces/${encodeURIComponent(workspaceId)}/latest-context-result`;
  try {
    const axiosInstance = createAxiosInstance();
    const response = await axiosInstance.get(url);
    const items = response.data?.data;
    if (!Array.isArray(items) || items.length === 0) {
      return [];
    }
    return items
      .filter((item: any) => item.contextId && item.fileContent)
      .map((item: any) => ({
        contextId: `${item.contextId}`,
        contextName: item.contextName || '',
        fileName: item.fileName || 'project-overview.md',
        fileContent: item.fileContent
      }));
  } catch (error) {
    throw new Error(`Failed to fetch context results from ${url}: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Write context content (markdown) to workspace context directory.
 * Dir structure: .asdm/workspaces/{wsId}/contexts/{contextName}_{contextId}/{fileName}
 */
export function installWorkspaceContextContent(workspaceId: string, contextId: string, contextName: string, fileName: string, fileContent: string): void {
  const dirName = contextName ? `${contextName}_${contextId}` : contextId;
  const filePath = path.join(getAsdmRootPath(), 'workspaces', workspaceId, 'contexts', dirName, fileName);
  ensureDirectoryExists(path.dirname(filePath));
  fs.writeFileSync(filePath, fileContent, 'utf8');
}

/**
 * Extract a ZIP file to the target directory
 * Handles nested folder structure in ZIP files
 */
export function extractZip(zipBuffer: Buffer, targetDir: string): void {
  try {
    const zip = new AdmZip(zipBuffer);
    const zipEntries = zip.getEntries();
    
    // Check if all entries are in a single root folder
    const rootFolders = new Set<string>();
    zipEntries.forEach(entry => {
      if (!entry.entryName.startsWith('__MACOSX')) {
        const parts = entry.entryName.split('/');
        if (parts.length > 0 && parts[0]) {
          rootFolders.add(parts[0]);
        }
      }
    });
    
    // If there's a single root folder (excluding __MACOSX), extract and flatten
    if (rootFolders.size === 1) {
      const rootFolder = Array.from(rootFolders)[0];
      const tempDir = path.join(path.dirname(targetDir), `.temp-${Date.now()}`);
      
      // Extract to temp directory
      zip.extractAllTo(tempDir, true);
      
      // Move contents from nested folder to target
      const nestedPath = path.join(tempDir, rootFolder);
      if (fs.existsSync(nestedPath)) {
        // Ensure target directory exists
        ensureDirectoryExists(targetDir);
        
        // Move all files from nested folder to target
        const items = fs.readdirSync(nestedPath);
        items.forEach(item => {
          const srcPath = path.join(nestedPath, item);
          const destPath = path.join(targetDir, item);
          fs.renameSync(srcPath, destPath);
        });
      }
      
      // Clean up temp directory
      fs.rmSync(tempDir, { recursive: true, force: true });
    } else {
      // Extract normally if no single root folder
      zip.extractAllTo(targetDir, true);
    }
  } catch (error) {
    throw new Error(`Failed to extract ZIP: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Ensure a directory exists, create it if it doesn't
 */
export function ensureDirectoryExists(dirPath: string): void {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

/**
 * Get the installation path for a toolset
 */
export function getToolsetInstallPath(toolsetId: string): string {
  const cwd = process.cwd();
  return path.join(cwd, LOCAL_TOOLSETS_DIR, toolsetId);
}

/**
 * Get the installation path for a spec
 */
export function getSpecInstallPath(specId: string): string {
  const cwd = process.cwd();
  return path.join(cwd, LOCAL_SPECS_DIR, specId);
}

/** Per-workspace sandbox under `.asdm/workspaces/<workspaceId>/` (isolated from global `asdm toolset install`). */
export function getWorkspaceRootPath(workspaceId: string): string {
  return path.join(getAsdmRootPath(), 'workspaces', workspaceId);
}

export function getWorkspaceToolsetInstallPath(workspaceId: string, toolsetId: string): string {
  return path.join(getWorkspaceRootPath(workspaceId), 'toolsets', toolsetId);
}

export function getWorkspaceSpecInstallPath(workspaceId: string, specId: string): string {
  return path.join(getWorkspaceRootPath(workspaceId), 'specs', specId);
}

export function isWorkspaceToolsetInstalled(workspaceId: string, toolsetId: string): boolean {
  return fs.existsSync(getWorkspaceToolsetInstallPath(workspaceId, toolsetId));
}

export function isWorkspaceSpecInstalled(workspaceId: string, specId: string): boolean {
  return fs.existsSync(getWorkspaceSpecInstallPath(workspaceId, specId));
}

export function removeWorkspaceScopedToolset(workspaceId: string, toolsetId: string): void {
  const installPath = getWorkspaceToolsetInstallPath(workspaceId, toolsetId);
  if (fs.existsSync(installPath)) {
    fs.rmSync(installPath, { recursive: true, force: true });
  }
}

export function removeWorkspaceScopedSpec(workspaceId: string, specId: string): void {
  const installPath = getWorkspaceSpecInstallPath(workspaceId, specId);
  if (fs.existsSync(installPath)) {
    fs.rmSync(installPath, { recursive: true, force: true });
  }
}

export function removeWorkspaceSandboxDirectory(workspaceId: string): void {
  const root = getWorkspaceRootPath(workspaceId);
  if (fs.existsSync(root)) {
    fs.rmSync(root, { recursive: true, force: true });
  }
}

export function getWorkspaceContextInstallPath(workspaceId: string, contextId: string): string {
  return path.join(getWorkspaceRootPath(workspaceId), 'contexts', contextId);
}

export function isWorkspaceContextInstalled(workspaceId: string, contextId: string): boolean {
  return fs.existsSync(getWorkspaceContextInstallPath(workspaceId, contextId));
}

export function removeWorkspaceScopedContext(workspaceId: string, contextId: string): void {
  const installPath = getWorkspaceContextInstallPath(workspaceId, contextId);
  if (fs.existsSync(installPath)) {
    fs.rmSync(installPath, { recursive: true, force: true });
  }
}

/**
 * Get the installation path for a context
 */
export function getContextInstallPath(contextId: string): string {
  const cwd = process.cwd();
  return path.join(cwd, LOCAL_CONTEXTS_DIR, contextId);
}

/**
 * Check if a toolset is already installed
 */
export function isToolsetInstalled(toolsetId: string): boolean {
  const installPath = getToolsetInstallPath(toolsetId);
  return fs.existsSync(installPath);
}

/**
 * Check if a spec is already installed
 */
export function isSpecInstalled(specId: string): boolean {
  const installPath = getSpecInstallPath(specId);
  return fs.existsSync(installPath);
}

/**
 * Check if a context is already installed
 */
export function isContextInstalled(contextId: string): boolean {
  const installPath = getContextInstallPath(contextId);
  return fs.existsSync(installPath);
}

/**
 * Remove an installed toolset
 */
export function removeToolset(toolsetId: string): void {
  const installPath = getToolsetInstallPath(toolsetId);
  if (fs.existsSync(installPath)) {
    fs.rmSync(installPath, { recursive: true, force: true });
  }
}

/** Multi-workspace install manifest: which toolset/spec ids each workspace claims (for refcount uninstall). */
export const WORKSPACE_INSTALLS_FILE = 'workspace-installs.json';

/** @deprecated Use WORKSPACE_INSTALLS_FILE; kept for docs/migration only */
export const ACTIVE_WORKSPACE_FILE = 'active-workspace.json';

const CODEBUDDY_COMMANDS_REL = path.join('.codebuddy', 'commands');

export interface WorkspaceInstallRecord {
  registryVersion?: string;
  toolsetIds: string[];
  specIds: string[];
  contextIds: string[];
  updatedAt: string;
}

export interface WorkspaceInstallsState {
  /** Current workspace (`workspace switch`). Persisted as **`activeWorkspaceId`** in JSON. */
  activeWorkspaceId?: string;
  /** Workspaces merged into CodeBuddy slash commands (subset or superset of active). */
  codeBuddyWorkspaceIds: string[];
  workspaces: Record<string, WorkspaceInstallRecord>;
}

/** Thrown when `workspace switch` targets an id that has no manifest entry (never installed). */
export class WorkspaceNotInstalledError extends Error {
  constructor(public readonly workspaceId: string) {
    super(`Workspace not installed: ${workspaceId}`);
    this.name = 'WorkspaceNotInstalledError';
  }
}

function getWorkspaceInstallsPath(): string {
  return path.join(getAsdmRootPath(), WORKSPACE_INSTALLS_FILE);
}

function getLegacyActiveWorkspacePath(): string {
  return path.join(getAsdmRootPath(), ACTIVE_WORKSPACE_FILE);
}

function normalizeWorkspaceInstallsState(raw: any): WorkspaceInstallsState {
  const workspaces: Record<string, WorkspaceInstallRecord> = {};
  if (raw && typeof raw.workspaces === 'object' && raw.workspaces !== null) {
    for (const [wid, rec] of Object.entries(raw.workspaces)) {
      const r = rec as any;
      if (!r || !Array.isArray(r.toolsetIds)) {
        continue;
      }
      workspaces[wid] = {
        registryVersion: r.registryVersion,
        toolsetIds: [...r.toolsetIds],
        specIds: Array.isArray(r.specIds) ? [...r.specIds] : [],
        contextIds: Array.isArray(r.contextIds) ? [...r.contextIds] : [],
        updatedAt: typeof r.updatedAt === 'string' ? r.updatedAt : new Date().toISOString()
      };
    }
  }

  const keys = Object.keys(workspaces);
  let activeWorkspaceId: string | undefined;
  if (typeof raw?.activeWorkspaceId === 'string' && raw.activeWorkspaceId) {
    activeWorkspaceId = raw.activeWorkspaceId;
  } else if (typeof raw?.current === 'string' && raw.current) {
    activeWorkspaceId = raw.current;
  }

  let codeBuddyWorkspaceIds: string[] = Array.isArray(raw?.codeBuddyWorkspaceIds)
    ? (raw.codeBuddyWorkspaceIds as unknown[]).filter((x): x is string => typeof x === 'string')
    : [];

  codeBuddyWorkspaceIds = codeBuddyWorkspaceIds.filter((id) => Boolean(workspaces[id]));

  if (activeWorkspaceId && !workspaces[activeWorkspaceId]) {
    activeWorkspaceId = undefined;
  }

  if (!activeWorkspaceId && keys.length === 1) {
    activeWorkspaceId = keys[0];
  }
  if (codeBuddyWorkspaceIds.length === 0 && activeWorkspaceId) {
    codeBuddyWorkspaceIds = [activeWorkspaceId];
  }

  return { activeWorkspaceId, codeBuddyWorkspaceIds, workspaces };
}

function migrateLegacyActiveWorkspaceIfNeeded(): WorkspaceInstallsState | null {
  const legacyPath = getLegacyActiveWorkspacePath();
  if (!fs.existsSync(legacyPath)) {
    return null;
  }
  try {
    const raw = JSON.parse(fs.readFileSync(legacyPath, 'utf8')) as any;
    if (!raw.workspaceId || !Array.isArray(raw.toolsetIds)) {
      return null;
    }
    const wid = raw.workspaceId as string;
    const state: WorkspaceInstallsState = {
      activeWorkspaceId: wid,
      codeBuddyWorkspaceIds: [wid],
      workspaces: {
        [wid]: {
          registryVersion: raw.registryVersion,
          toolsetIds: [...raw.toolsetIds],
          specIds: Array.isArray(raw.specIds) ? [...raw.specIds] : [],
          contextIds: Array.isArray(raw.contextIds) ? [...raw.contextIds] : [],
          updatedAt: typeof raw.updatedAt === 'string' ? raw.updatedAt : new Date().toISOString()
        }
      }
    };
    writeWorkspaceInstallsState(state);
    fs.unlinkSync(legacyPath);
    return state;
  } catch {
    return null;
  }
}

export function readWorkspaceInstallsState(): WorkspaceInstallsState {
  const p = getWorkspaceInstallsPath();
  if (fs.existsSync(p)) {
    try {
      const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
      return normalizeWorkspaceInstallsState(raw);
    } catch {
      return { activeWorkspaceId: undefined, codeBuddyWorkspaceIds: [], workspaces: {} };
    }
  }
  const migrated = migrateLegacyActiveWorkspaceIfNeeded();
  if (migrated) {
    return migrated;
  }
  return { activeWorkspaceId: undefined, codeBuddyWorkspaceIds: [], workspaces: {} };
}

export function writeWorkspaceInstallsState(state: WorkspaceInstallsState): void {
  ensureDirectoryExists(getAsdmRootPath());
  const payload = {
    version: 2,
    activeWorkspaceId: state.activeWorkspaceId ?? null,
    codeBuddyWorkspaceIds: state.codeBuddyWorkspaceIds,
    workspaces: state.workspaces
  };
  fs.writeFileSync(getWorkspaceInstallsPath(), `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
}

/** Workspaces that contribute to CodeBuddy (explicit list, or [active] when list empty). */
export function getResolvedCodeBuddyWorkspaceIds(state: WorkspaceInstallsState): string[] {
  const listed = state.codeBuddyWorkspaceIds.filter((id) => state.workspaces[id]);
  if (listed.length > 0) {
    return [...new Set(listed)];
  }
  if (state.activeWorkspaceId && state.workspaces[state.activeWorkspaceId]) {
    return [state.activeWorkspaceId];
  }
  return [];
}

export function switchWorkspace(workspaceId: string): void {
  const state = readWorkspaceInstallsState();
  if (!state.workspaces[workspaceId]) {
    throw new WorkspaceNotInstalledError(workspaceId);
  }
  state.activeWorkspaceId = workspaceId;
  state.codeBuddyWorkspaceIds = [workspaceId];
  writeWorkspaceInstallsState(state);
}

export function addCodeBuddyWorkspace(workspaceId: string): void {
  const state = readWorkspaceInstallsState();
  if (!state.codeBuddyWorkspaceIds.includes(workspaceId)) {
    state.codeBuddyWorkspaceIds = [...state.codeBuddyWorkspaceIds, workspaceId];
  }
  writeWorkspaceInstallsState(state);
}

export function removeCodeBuddyWorkspaceEntry(workspaceId: string): void {
  const state = readWorkspaceInstallsState();
  state.codeBuddyWorkspaceIds = state.codeBuddyWorkspaceIds.filter((id) => id !== workspaceId);
  writeWorkspaceInstallsState(state);
}

export function setCodeBuddyWorkspacesOnly(workspaceIds: string[]): void {
  const state = readWorkspaceInstallsState();
  state.codeBuddyWorkspaceIds = [...new Set(workspaceIds)];
  writeWorkspaceInstallsState(state);
}

export function resetCodeBuddyWorkspacesToActive(): void {
  const state = readWorkspaceInstallsState();
  state.codeBuddyWorkspaceIds = state.activeWorkspaceId ? [state.activeWorkspaceId] : [];
  writeWorkspaceInstallsState(state);
}

function pruneEmptyWorkspaceEntry(state: WorkspaceInstallsState, workspaceId: string): void {
  const rec = state.workspaces[workspaceId];
  if (rec && rec.toolsetIds.length === 0 && rec.specIds.length === 0 && rec.contextIds.length === 0) {
    delete state.workspaces[workspaceId];
  }
}

/** Ensure this workspace id is recorded (e.g. after `workspace toolset install`). */
export function addToolsetToWorkspaceInstall(workspaceId: string, toolsetId: string): void {
  const state = readWorkspaceInstallsState();
  const prev = state.workspaces[workspaceId] || {
    toolsetIds: [],
    specIds: [],
    contextIds: [],
    updatedAt: new Date().toISOString()
  };
  if (prev.toolsetIds.includes(toolsetId)) {
    return;
  }
  state.workspaces[workspaceId] = {
    ...prev,
    toolsetIds: [...prev.toolsetIds, toolsetId],
    updatedAt: new Date().toISOString()
  };
  writeWorkspaceInstallsState(state);
}

/** Remove toolset id from one workspace’s claim; does not touch disk (caller uses refcount). */
export function removeToolsetFromWorkspaceInstall(workspaceId: string, toolsetId: string): void {
  const state = readWorkspaceInstallsState();
  const rec = state.workspaces[workspaceId];
  if (!rec) {
    return;
  }
  state.workspaces[workspaceId] = {
    ...rec,
    toolsetIds: rec.toolsetIds.filter((id) => id !== toolsetId),
    updatedAt: new Date().toISOString()
  };
  pruneEmptyWorkspaceEntry(state, workspaceId);
  writeWorkspaceInstallsState(state);
}

export function upsertWorkspaceInstallManifest(
  workspaceId: string,
  toolsetIds: string[],
  specIds: string[],
  contextIds: string[],
  registryVersion?: string
): { droppedToolsetIds: string[]; droppedSpecIds: string[]; droppedContextIds: string[] } {
  const state = readWorkspaceInstallsState();
  const prev = state.workspaces[workspaceId];
  const oldToolsetIds = prev?.toolsetIds ?? [];
  const oldSpecIds = prev?.specIds ?? [];
  const oldContextIds = prev?.contextIds ?? [];
  const nextToolsetSet = new Set(toolsetIds);
  const nextSpecSet = new Set(specIds);
  const nextContextSet = new Set(contextIds);
  const droppedToolsetIds = oldToolsetIds.filter((id) => !nextToolsetSet.has(id));
  const droppedSpecIds = oldSpecIds.filter((id) => !nextSpecSet.has(id));
  const droppedContextIds = oldContextIds.filter((id) => !nextContextSet.has(id));

  state.workspaces[workspaceId] = {
    registryVersion,
    toolsetIds: [...toolsetIds],
    specIds: [...specIds],
    contextIds: [...contextIds],
    updatedAt: new Date().toISOString()
  };

  if (!state.activeWorkspaceId) {
    state.activeWorkspaceId = workspaceId;
  }
  if (state.codeBuddyWorkspaceIds.length === 0) {
    state.codeBuddyWorkspaceIds = state.activeWorkspaceId ? [state.activeWorkspaceId] : [workspaceId];
  }

  writeWorkspaceInstallsState(state);
  return { droppedToolsetIds, droppedSpecIds, droppedContextIds };
}

/** Remove dropped ids only under this workspace sandbox (paths are isolated per workspace). */
export function pruneDroppedWorkspaceResources(
  workspaceId: string,
  droppedToolsetIds: string[],
  droppedSpecIds: string[],
  droppedContextIds: string[]
): void {
  for (const id of droppedToolsetIds) {
    removeWorkspaceScopedToolset(workspaceId, id);
  }
  for (const id of droppedSpecIds) {
    removeWorkspaceScopedSpec(workspaceId, id);
  }
  for (const id of droppedContextIds) {
    removeWorkspaceScopedContext(workspaceId, id);
  }
}

/** Remove manifest entry and delete `.asdm/workspaces/<id>/` entirely. */
export function removeWorkspaceInstallAndPruneDisk(workspaceId: string): WorkspaceInstallRecord | null {
  const state = readWorkspaceInstallsState();
  const rec = state.workspaces[workspaceId];
  if (!rec) {
    return null;
  }
  delete state.workspaces[workspaceId];
  removeWorkspaceSandboxDirectory(workspaceId);

  if (state.activeWorkspaceId === workspaceId) {
    const remaining = Object.keys(state.workspaces);
    state.activeWorkspaceId = remaining[0];
  }
  state.codeBuddyWorkspaceIds = state.codeBuddyWorkspaceIds.filter((id) => id !== workspaceId);
  if (state.codeBuddyWorkspaceIds.length === 0 && state.activeWorkspaceId) {
    state.codeBuddyWorkspaceIds = [state.activeWorkspaceId];
  }

  writeWorkspaceInstallsState(state);
  return rec;
}

export function removeToolsetsByIds(toolsetIds: string[]): void {
  for (const id of toolsetIds) {
    removeToolset(id);
  }
}

export function removeSpecsByIds(specIds: string[]): void {
  for (const id of specIds) {
    removeSpec(id);
  }
}

export function clearCodeBuddyAsdmCommands(): void {
  const dir = path.join(process.cwd(), CODEBUDDY_COMMANDS_REL);
  if (!fs.existsSync(dir)) {
    return;
  }
  for (const f of fs.readdirSync(dir)) {
    if (f === 'asdm-workspace.md' || (f.startsWith('asdm-toolset-') && f.endsWith('.md'))) {
      fs.unlinkSync(path.join(dir, f));
    }
  }
}

/** Regenerate CodeBuddy stubs from `getResolvedCodeBuddyWorkspaceIds` (multi-workspace merge for slash commands). */
export function syncCodeBuddyWorkspaceInstallsState(state: WorkspaceInstallsState): void {
  const cmdDir = path.join(process.cwd(), CODEBUDDY_COMMANDS_REL);
  ensureDirectoryExists(cmdDir);
  clearCodeBuddyAsdmCommands();

  const buddyIds = getResolvedCodeBuddyWorkspaceIds(state);
  const entries = buddyIds
    .map((wid) => [wid, state.workspaces[wid]] as const)
    .filter(([, rec]) => rec && (rec.toolsetIds.length > 0 || rec.specIds.length > 0));

  if (entries.length === 0) {
    return;
  }

  const cn = getCliLanguage() === 'CN';
  const active = state.activeWorkspaceId ?? '—';
  const buddyList = buddyIds.join('`, `');
  const indexLines: string[] = [
    '---',
    'description: ASDM workspace installs — toolset index (CodeBuddy)',
    '---',
    '',
    cn ? '# ASDM 工作区（CodeBuddy）' : '# ASDM workspaces (CodeBuddy)',
    '',
    cn
      ? `**当前工作区：** \`${active}\`（\`asdm workspace switch\`） · **并入斜杠指令的工作区：** \`${buddyList}\`（\`asdm workspace codebuddy …\`）`
      : `**Active workspace:** \`${active}\` (\`asdm workspace switch\`) · **Merged into slash commands:** \`${buddyList}\` (\`asdm workspace codebuddy …\`)`,
    '',
    cn
      ? '各工作区资源目录 **互相隔离**：`.asdm/workspaces/<workspace-id>/toolsets|specs/`。同一 toolset id 在不同工作区下是 **不同目录**。'
      : 'Each workspace is **isolated** under `.asdm/workspaces/<workspace-id>/toolsets|specs/`. Same toolset id in two workspaces means **two folders**.',
    '',
    cn ? '## 本索引包含的 toolset / spec' : '## Toolsets / specs in this CodeBuddy merge',
    ''
  ];

  const toolsetLocations = new Map<string, { workspaceId: string; relPath: string }[]>();

  for (const [wid, rec] of entries) {
    if (!rec) {
      continue;
    }
    indexLines.push(cn ? `### \`${wid}\`` : `### \`${wid}\``, '');
    if (rec.toolsetIds.length > 0) {
      indexLines.push(cn ? '**Toolsets:**' : '**Toolsets:**', '');
      for (const id of rec.toolsetIds) {
        const relPath = `${LOCAL_ASDM_DIR}/workspaces/${wid}/toolsets/${id}`;
        indexLines.push(`- \`${id}\` → \`${relPath}/\``);
        const list = toolsetLocations.get(id) ?? [];
        list.push({ workspaceId: wid, relPath: `${relPath}/` });
        toolsetLocations.set(id, list);
      }
      indexLines.push('');
    }
    if (rec.specIds.length > 0) {
      indexLines.push(cn ? '**Specs:**' : '**Specs:**', '');
      for (const id of rec.specIds) {
        const relPath = `${LOCAL_ASDM_DIR}/workspaces/${wid}/specs/${id}`;
        indexLines.push(`- \`${id}\` → \`${relPath}/\``);
      }
      indexLines.push('');
    }
  }

  fs.writeFileSync(path.join(cmdDir, 'asdm-workspace.md'), `${indexLines.join('\n')}\n`, 'utf8');

  for (const [tsId, locs] of toolsetLocations) {
    const safe = tsId.replace(/[^a-zA-Z0-9_-]/g, '_');
    const pathLines = locs.map(
      (l) =>
        cn
          ? `- **工作区 \`${l.workspaceId}\`:** \`${l.relPath}\``
          : `- **Workspace \`${l.workspaceId}\`:** \`${l.relPath}\``
    );
    const lines = [
      '---',
      `description: ASDM toolset ${tsId}`,
      '---',
      '',
      `# ${tsId}`,
      '',
      cn ? '## 安装路径（按工作区隔离）' : '## Install paths (per workspace)',
      '',
      ...pathLines,
      '',
      cn
        ? '若多个工作区包含同名 toolset，请根据当前任务选用对应路径下的 `INSTALL.md`。'
        : 'If multiple workspaces include the same toolset id, pick the path for the workspace you are using and follow its `INSTALL.md`.'
    ];
    fs.writeFileSync(path.join(cmdDir, `asdm-toolset-${safe}.md`), `${lines.join('\n')}\n`, 'utf8');
  }
}

/**
 * `.asdm/README.md` — flat toolsets layout + active workspace note.
 */
export function syncAsdmReadme(): void {
  const asdmRoot = getAsdmRootPath();
  ensureDirectoryExists(asdmRoot);
  const cn = getCliLanguage() === 'CN';
  const state = readWorkspaceInstallsState();
  const lines: string[] = [];

  if (cn) {
    lines.push(
      '# `.asdm` 目录说明',
      '',
      '全局 **`asdm toolset install` / `asdm spec install`** 仍写入 **`.asdm/toolsets/`**、**`.asdm/specs/`**；与工作区安装 **目录不同**。',
      '',
      '## Workspace 模式',
      '',
      '- **`asdm workspace install <workspace-id>`** 将资源装到 **`.asdm/workspaces/<id>/toolsets|specs/`**，与其它工作区 **磁盘隔离**；同一工作区内 **相同 id 覆盖**。',
      '- **`asdm workspace switch <workspace-id>`** 设定 **当前工作区**；默认 **CodeBuddy 斜杠指令** 只合并 **当前** 工作区（可用 `codebuddy` 子命令并入多个）。',
      '- **`asdm workspace codebuddy add|remove|only|reset|list`** 控制哪些工作区进入 CodeBuddy；`only` 可一次指定多个 id。',
      '- **`workspace-installs.json`** 记录各工作区清单、**`activeWorkspaceId`**（当前工作区）、`codeBuddyWorkspaceIds`。',
      '- **`asdm workspace uninstall <workspace-id>`** 删除该工作区 **整个** `.asdm/workspaces/<id>/` 及登记。',
      '- **`asdm workspace toolset uninstall`** 只删 **该工作区沙箱内** 对应目录。',
      '- 旧版 **`active-workspace.json`** 首次读取会迁移进 `workspace-installs.json` 后删除（旧版平铺 `.asdm/toolsets/` 需自行迁移或重装）。',
      ''
    );
  } else {
    lines.push(
      '# `.asdm` directory',
      '',
      'Global **`asdm toolset install`** / **`asdm spec install`** still use **`.asdm/toolsets/`** and **`.asdm/specs/`** — separate from workspace installs.',
      '',
      '## Workspace mode',
      '',
      '- **`asdm workspace install <workspace-id>`** installs under **`.asdm/workspaces/<id>/toolsets|specs/`** (**isolated** per workspace); **same id overwrites** within that workspace.',
      '- **`asdm workspace switch <workspace-id>`** sets the **active** workspace; CodeBuddy defaults to **that** workspace only (use **`workspace codebuddy`** to merge more).',
      '- **`asdm workspace codebuddy` `add|remove|only|reset|list`** controls which workspaces feed CodeBuddy; `only` accepts multiple ids.',
      '- **`workspace-installs.json`** stores each manifest, **`activeWorkspaceId`**, and `codeBuddyWorkspaceIds`.',
      '- **`asdm workspace uninstall <workspace-id>`** removes the whole **`.asdm/workspaces/<id>/`** tree and its record.',
      '- **`asdm workspace toolset uninstall`** removes files **only inside that workspace sandbox**.',
      '- Legacy **`active-workspace.json`** migrates once into `workspace-installs.json` (old flat `.asdm/toolsets/` installs need manual move or reinstall).',
      ''
    );
  }

  if (Object.keys(state.workspaces).length > 0 || state.activeWorkspaceId || state.codeBuddyWorkspaceIds.length > 0) {
    lines.push(
      cn ? '## 当前 `workspace-installs.json`' : '## Current `workspace-installs.json`',
      '',
      '```json',
      JSON.stringify(
        {
          version: 2,
          activeWorkspaceId: state.activeWorkspaceId ?? null,
          codeBuddyWorkspaceIds: state.codeBuddyWorkspaceIds,
          workspaces: state.workspaces
        },
        null,
        2
      ),
      '```',
      ''
    );
  } else {
    lines.push(
      cn ? '_（尚无 `workspace-installs.json` 记录。）_' : '_(No workspace install records yet.)_',
      ''
    );
  }

  fs.writeFileSync(path.join(asdmRoot, 'README.md'), `${lines.join('\n')}\n`, 'utf8');
}

/**
 * Remove an installed spec
 */
export function removeSpec(specId: string): void {
  const installPath = getSpecInstallPath(specId);
  if (fs.existsSync(installPath)) {
    fs.rmSync(installPath, { recursive: true, force: true });
  }
}

/**
 * Remove an installed context
 */
export function removeContext(contextId: string): void {
  const installPath = getContextInstallPath(contextId);
  if (fs.existsSync(installPath)) {
    fs.rmSync(installPath, { recursive: true, force: true });
  }
}

/**
 * Fetch the skills registry
 */
export async function fetchSkillsRegistry(): Promise<SkillsRegistry> {
  try {
    const axiosInstance = createAxiosInstance();
    const response = await axiosInstance.get<SkillsRegistry>(SKILLS_REGISTRY_URL);
    return response.data;
  } catch (error) {
    throw new Error(`Failed to fetch skills registry: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Download a skill ZIP file
 */
export async function downloadSkill(skillId: string, downloadUrl: string): Promise<{ buffer: Buffer; actualUrl: string }> {
  const fullDownloadUrl = downloadUrl.startsWith('http') 
    ? downloadUrl 
    : `${SKILLS_BASE_URL}/${downloadUrl}`;
  
  try {
    const axiosInstance = createAxiosInstance();
    const response = await axiosInstance.get(fullDownloadUrl, {
      responseType: 'arraybuffer'
    });
    return { 
      buffer: Buffer.from(response.data),
      actualUrl: fullDownloadUrl
    };
  } catch (error) {
    throw new Error(`Failed to download skill: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Get the installation path for a skill
 */
export function getSkillInstallPath(skillId: string): string {
  const cwd = process.cwd();
  return path.join(cwd, LOCAL_SKILLS_DIR, skillId);
}

/**
 * Check if a skill is already installed
 */
export function isSkillInstalled(skillId: string): boolean {
  const installPath = getSkillInstallPath(skillId);
  return fs.existsSync(installPath);
}

/**
 * Remove an installed skill
 */
export function removeSkill(skillId: string): void {
  const installPath = getSkillInstallPath(skillId);
  if (fs.existsSync(installPath)) {
    fs.rmSync(installPath, { recursive: true, force: true });
  }
}
