export interface Toolset {
  id: string;
  name: string;
  description: string | null;
  version: string | null;
  downloadUrl: string | null;
  entryPoint: string | null;
}

export interface Spec {
  id: string;
  name: string;
  description: string | null;
  version: string | null;
  downloadUrl: string | null;
  entryPoint: string | null;
}

export interface Context {
  id: string;
  name: string;
  description: string | null;
  version: string | null;
  downloadUrl: string | null;
  entryPoint: string | null;
}

export interface Skill {
  id: string;
  name: string;
  description: string;
  version: string;
  downloadUrl: string;
}

export interface ToolsetRegistry {
  version: string;
  workspaceId?: string;
  toolsets: Toolset[];
  specs?: Spec[];
  contexts?: Context[];
}

export interface SpecsRegistry {
  version: string;
  specs: Spec[];
}

export interface ContextsRegistry {
  version: string;
  contexts: Context[];
}

export interface SkillsRegistry {
  version: string;
  skills: Skill[];
}
