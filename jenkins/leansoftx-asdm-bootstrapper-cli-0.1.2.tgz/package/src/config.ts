import { config } from 'dotenv';
import * as path from 'path';
import { getBaseUrlFromConfig, getArtifactBaseUrlFromConfig } from './user-config';

// Load environment variables from .env file
config();

// Base URL for ASDM platform (ensure no trailing slash for consistent URL building)
const normalizeUrl = (url: string): string => url.replace(/\/+$/, '');
const normalizePath = (urlPath: string): string => (urlPath.startsWith('/') ? urlPath : `/${urlPath}`);
export const BASE_URL = normalizeUrl(process.env.BASE_URL || getBaseUrlFromConfig() || 'https://platform.asdm.ai');

// Registry URLs for different resource types
export const TOOLSET_REGISTRY_URL = process.env.TOOLSET_REGISTRY_URL || `${BASE_URL}/_ai/toolsets/registry`;
export const SPECS_REGISTRY_URL = process.env.SPECS_REGISTRY_URL || `${BASE_URL}/_ai/specs/registry`;
export const CONTEXTS_REGISTRY_URL = process.env.CONTEXTS_REGISTRY_URL || ''; // Reserved for future implementation
export const SKILLS_REGISTRY_URL = process.env.SKILLS_REGISTRY_URL || `${BASE_URL}/_ai/skills/registry`;

// Workspace resources-manifest API (returns toolsets + specs + contexts in one call)
// Default: {BASE_URL}/api/workspaces/{wsId}/resources-manifest
const DEFAULT_WORKSPACE_RESOURCES_MANIFEST_PATH = '/api/workspaces/{wsId}/resources-manifest';
export const WORKSPACE_RESOURCES_MANIFEST_API_PATH =
  process.env.WORKSPACE_RESOURCES_MANIFEST_API_PATH ||
  process.env.WORKSPACE_RESOURCES_MANIFEST_URL ||
  DEFAULT_WORKSPACE_RESOURCES_MANIFEST_PATH;
export const WORKSPACE_RESOURCES_MANIFEST_URL =
  WORKSPACE_RESOURCES_MANIFEST_API_PATH.startsWith('http')
    ? WORKSPACE_RESOURCES_MANIFEST_API_PATH
    : `${BASE_URL}${normalizePath(WORKSPACE_RESOURCES_MANIFEST_API_PATH)}`;

export const USE_WORKSPACE_TOOLSETS_MOCK = process.env.USE_WORKSPACE_TOOLSETS_MOCK === 'true';
export const WORKSPACE_TOOLSETS_MOCK_FILE = process.env.WORKSPACE_TOOLSETS_MOCK_FILE || path.join(process.cwd(), 'mock', 'workspace-toolsets.json');

// Artifact download base URL — override to point artifacts at a different server/path
// Priority: ARTIFACT_BASE_URL env > artifactBaseUrl in ~/.asdm/config.json > fallback to BASE_URL/_artifacts
export const ARTIFACT_BASE_URL = normalizeUrl(
  process.env.ARTIFACT_BASE_URL || getArtifactBaseUrlFromConfig() || ''
);
const artifactRoot = ARTIFACT_BASE_URL || `${BASE_URL}/_artifacts`;

// Base URLs for downloading resources
export const TOOLSET_BASE_URL = `${artifactRoot}/toolsets`;
export const SPECS_BASE_URL = `${artifactRoot}/specs`;
export const CONTEXTS_BASE_URL = `${artifactRoot}/contexts`;
export const SKILLS_BASE_URL = `${artifactRoot}/skills`;

// SSL verification (set to 'false' to enable SSL verification in production)
// Default: true (skip SSL verification) to handle self-signed certificates in development
export const SKIP_SSL_VERIFICATION = process.env.SKIP_SSL_VERIFICATION !== 'false';

// Local directories for installed resources
export const LOCAL_TOOLSETS_DIR = '.asdm/toolsets';
export const LOCAL_SPECS_DIR = '.asdm/specs';
export const LOCAL_CONTEXTS_DIR = '.asdm/contexts';
export const LOCAL_SKILLS_DIR = '.asdm/skills';

/** Root `.asdm` under cwd; workspace installs use `.asdm/workspaces/<id>/`. */
export const LOCAL_ASDM_DIR = '.asdm';
/** Workspace sandboxes: `.asdm/workspaces/<workspace-id>/` */
export const LOCAL_WORKSPACES_DIR = '.asdm/workspaces';
