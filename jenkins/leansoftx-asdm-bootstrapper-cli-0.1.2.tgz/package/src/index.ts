#!/usr/bin/env node

import { Command } from 'commander';
import chalk from 'chalk';
import Table from 'cli-table3';
import {
  fetchToolsetRegistry,
  fetchWorkspaceResourcesManifest,
  fetchSpecsRegistry,
  fetchContextsRegistry,
  fetchSkillsRegistry,
  downloadToolset,
  downloadSpec,
  downloadContext,
  downloadSkill,
  fetchLatestContextResults,
  installWorkspaceContextContent,
  extractZip,
  ensureDirectoryExists,
  getToolsetInstallPath,
  readWorkspaceInstallsState,
  upsertWorkspaceInstallManifest,
  removeWorkspaceInstallAndPruneDisk,
  addToolsetToWorkspaceInstall,
  removeToolsetFromWorkspaceInstall,
  pruneDroppedWorkspaceResources,
  getWorkspaceToolsetInstallPath,
  getWorkspaceSpecInstallPath,
  isWorkspaceToolsetInstalled,
  isWorkspaceSpecInstalled,
  removeWorkspaceScopedToolset,
  removeWorkspaceScopedSpec,
  removeWorkspaceScopedContext,
  getWorkspaceContextInstallPath,
  isWorkspaceContextInstalled,
  switchWorkspace,
  WorkspaceNotInstalledError,
  addCodeBuddyWorkspace,
  removeCodeBuddyWorkspaceEntry,
  setCodeBuddyWorkspacesOnly,
  resetCodeBuddyWorkspacesToActive,
  getResolvedCodeBuddyWorkspaceIds,
  syncCodeBuddyWorkspaceInstallsState,
  syncAsdmReadme,
  WORKSPACE_INSTALLS_FILE,
  getSpecInstallPath,
  getContextInstallPath,
  getSkillInstallPath,
  isToolsetInstalled,
  isSpecInstalled,
  isContextInstalled,
  isSkillInstalled,
  removeToolset,
  removeSpec,
  removeContext,
  removeSkill
} from './utils';

// Read version from package.json
import { readFileSync } from 'fs';
import { join } from 'path';
import { LOCAL_ASDM_DIR } from './config';
import { t } from './i18n';
import type { ToolsetRegistry } from './types';
import {
  ensureUserConfigWithDefaults,
  getArtifactBaseUrlFromConfig,
  getBaseUrlFromConfig,
  getConfigPath,
  getLanguage,
  normalizeLanguage,
  writeArtifactBaseUrl,
  writeBaseUrl,
  writeLanguage
} from './user-config';

const packageJsonPath = join(__dirname, '../package.json');
const packageJson = JSON.parse(readFileSync(packageJsonPath, 'utf8'));
const version = packageJson.version;

function localizeWorkspaceError(error: unknown): string {
  const rawMessage = error instanceof Error ? error.message : 'Unknown error';
  const prefix = 'Failed to fetch workspace toolsets registry:';
  if (rawMessage.startsWith(prefix)) {
    const detail = rawMessage.slice(prefix.length).trim();
    return t(`获取工作区 toolsets 失败：${detail}`, `Failed to fetch workspace toolsets registry: ${detail}`);
  }
  return rawMessage;
}

function buildWorkspaceToolsetsTable(registry: ToolsetRegistry) {
  const table = new Table({
    head: [
      chalk.cyan.bold(t('名称', 'Name')),
      chalk.cyan.bold(t('描述', 'Description'))
    ],
    wordWrap: true
  });

  registry.toolsets.forEach((toolset) => {
    table.push([
      toolset.name,
      toolset.description || '—'
    ]);
  });

  return table;
}

const program = new Command();

program
  .name('asdm-bootstrapper')
  .description(`ASDM Bootstrapper CLI Tool (v${version})`)
  .version(version);

// ==================== CONFIG COMMAND ====================

const configCommand = program
  .command('config')
  .description(t('配置管理命令', 'Configuration management commands'));

configCommand
  .command('init')
  .description(t('初始化用户配置文件（~/.asdm/config.json）', 'Initialize user config file (~/.asdm/config.json)'))
  .action(() => {
    try {
      ensureUserConfigWithDefaults();
      console.log(chalk.green(t('✓ 配置文件已初始化/补全默认值。', '✓ Config file initialized / default values ensured.')));
      console.log(chalk.gray(`${t('配置文件', 'Config file')}: ${getConfigPath()}`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

configCommand
  .option('--set-language <lang>', t('设置语言：CN 或 US', 'Set language: CN or US'))
  .option('--set-base-url <url>', t('设置 BASE_URL', 'Set BASE_URL'))
  .option('--set-artifact-base-url <url>', t('设置 artifact 下载基地址', 'Set artifact download base URL'))
  .action((options: { setLanguage?: string; setBaseUrl?: string; setArtifactBaseUrl?: string }) => {
    try {
      if (options.setBaseUrl) {
        writeBaseUrl(options.setBaseUrl.trim());
        console.log(chalk.green(t(`BASE_URL 已设置为 ${options.setBaseUrl.trim()}。`, `BASE_URL set to ${options.setBaseUrl.trim()}.`)));
        console.log(chalk.gray(`${t('配置文件', 'Config file')}: ${getConfigPath()}`));
        return;
      }

      if (options.setArtifactBaseUrl) {
        writeArtifactBaseUrl(options.setArtifactBaseUrl.trim());
        console.log(chalk.green(t(`ARTIFACT_BASE_URL 已设置为 ${options.setArtifactBaseUrl.trim()}。`, `ARTIFACT_BASE_URL set to ${options.setArtifactBaseUrl.trim()}.`)));
        console.log(chalk.gray(`${t('配置文件', 'Config file')}: ${getConfigPath()}`));
        return;
      }

      if (options.setLanguage) {
        const normalized = normalizeLanguage(options.setLanguage);
        if (!normalized) {
          console.error(chalk.red(t('语言必须是 CN 或 US。', 'Language must be CN or US.')));
          process.exit(1);
        }

        writeLanguage(normalized);
        console.log(chalk.green(t(`语言已设置为 ${normalized}。`, `Language set to ${normalized}.`)));
        console.log(chalk.gray(`${t('配置文件', 'Config file')}: ${getConfigPath()}`));
        return;
      }

      const currentLanguage = getLanguage();
      console.log(chalk.green(`${t('当前语言', 'Current language')}: ${currentLanguage}`));
      console.log(chalk.green(`BASE_URL: ${getBaseUrlFromConfig()}`));
      const artifactUrl = getArtifactBaseUrlFromConfig();
      if (artifactUrl) {
        console.log(chalk.green(`ARTIFACT_BASE_URL: ${artifactUrl}`));
      }
      console.log(chalk.gray(`${t('配置文件', 'Config file')}: ${getConfigPath()}`));
      console.log(chalk.gray(`${t('设置命令', 'Set command')}: asdm config --set-language CN|US`));
      console.log(chalk.gray('asdm config --set-base-url <url>'));
      console.log(chalk.gray('asdm config --set-artifact-base-url <url>'));
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// ==================== TOOLSET COMMANDS ====================

// Create toolset subcommand
const toolsetCommand = program
  .command('toolset')
  .description('Toolset management commands');

// Toolset list command
toolsetCommand
  .command('list')
  .description('List all available ASDM toolsets')
  .action(async () => {
    try {
      console.log(chalk.blue('Fetching available ASDM toolsets...'));
      const { TOOLSET_REGISTRY_URL } = await import('./config');
      console.log(chalk.gray(`Registry URL: ${TOOLSET_REGISTRY_URL}`));

      const registry = await fetchToolsetRegistry();

      console.log(chalk.green(`\nAvailable toolsets (Registry version: ${registry.version}):\n`));

      if (registry.toolsets.length === 0) {
        console.log(chalk.yellow('No toolsets available.'));
        return;
      }

      // Create table
      const table = new Table({
        head: [
          chalk.cyan.bold('Status'),
          chalk.cyan.bold('ID'),
          chalk.cyan.bold('Version'),
          chalk.cyan.bold('Name'),
          chalk.cyan.bold('Description')
        ],
        colWidths: [15, 20, 10, 25, 50],
        wordWrap: true
      });

      registry.toolsets.forEach((toolset) => {
        const installed = isToolsetInstalled(toolset.id);
        const status = installed ? chalk.green('✓ Installed') : chalk.gray('○ Available');

        table.push([
          status,
          chalk.bold(toolset.id),
          toolset.version,
          toolset.name,
          toolset.description
        ]);
      });

      console.log(table.toString());
      console.log(chalk.gray(`\nTotal: ${registry.toolsets.length} toolsets`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// Toolset install command
toolsetCommand
  .command('install <toolset-id>')
  .description('Download and install a specific ASDM toolset')
  .action(async (toolsetId: string) => {
    try {
      console.log(chalk.blue(`Installing toolset: ${toolsetId}...`));

      // Check if already installed
      if (isToolsetInstalled(toolsetId)) {
        console.log(chalk.yellow(`Toolset '${toolsetId}' is already installed.`));
        console.log(chalk.gray(`Location: ${getToolsetInstallPath(toolsetId)}`));
        return;
      }

      // Fetch registry to validate toolset exists
      console.log(chalk.blue('Fetching registry...'));
      const registry = await fetchToolsetRegistry();
      const toolset = registry.toolsets.find(t => t.id === toolsetId);

      if (!toolset) {
        console.error(chalk.red(`Error: Toolset '${toolsetId}' not found in registry.`));
        console.log(chalk.gray('Run "asdm toolset list" to see available toolsets.'));
        process.exit(1);
      }

      // Download toolset
      console.log(chalk.blue(`Downloading ${toolset.name} (v${toolset.version})...`));
      const downloadResult = await downloadToolset(toolsetId, toolset.downloadUrl);
      console.log(chalk.gray(`  Downloading from: ${downloadResult.actualUrl}`));

      // Prepare installation directory
      const installPath = getToolsetInstallPath(toolsetId);
      ensureDirectoryExists(installPath);

      // Extract toolset
      console.log(chalk.blue('Extracting files...'));
      extractZip(downloadResult.buffer, installPath);

      console.log(chalk.green(`✓ Successfully installed '${toolsetId}'`));
      console.log(chalk.gray(`Location: ${installPath}`));

      // Output instruction for AI Model
      const installMdPath = `${installPath}/INSTALL.md`;
      console.log(chalk.cyan('\n📋 AI Model Instruction:'));
      console.log(chalk.white(`  follow instructions ${installMdPath}`));
    } catch (error) {
      console.log(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// Toolset update command
toolsetCommand
  .command('update <toolset-id>')
  .description('Update a specific ASDM toolset')
  .action(async (toolsetId: string) => {
    try {
      console.log(chalk.blue(`Updating toolset: ${toolsetId}...`));

      // Check if installed
      if (!isToolsetInstalled(toolsetId)) {
        console.log(chalk.yellow(`Toolset '${toolsetId}' is not installed.`));
        console.log(chalk.gray('Run "asdm toolset install <toolset-id>" to install it first.'));
        return;
      }

      // Remove old version
      console.log(chalk.blue('Removing old version...'));
      removeToolset(toolsetId);

      // Fetch registry to get latest version
      console.log(chalk.blue('Fetching latest version...'));
      const registry = await fetchToolsetRegistry();
      const toolset = registry.toolsets.find(t => t.id === toolsetId);

      if (!toolset) {
        console.error(chalk.red(`Error: Toolset '${toolsetId}' not found in registry.`));
        process.exit(1);
      }

      // Download and install new version
      console.log(chalk.blue(`Downloading ${toolset.name} (v${toolset.version})...`));
      const downloadResult = await downloadToolset(toolsetId, toolset.downloadUrl);

      const installPath = getToolsetInstallPath(toolsetId);
      ensureDirectoryExists(installPath);

      console.log(chalk.blue('Extracting files...'));
      extractZip(downloadResult.buffer, installPath);

      console.log(chalk.green(`✓ Successfully updated '${toolsetId}' to v${toolset.version}`));
      console.log(chalk.gray(`Location: ${installPath}`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// Toolset uninstall command
toolsetCommand
  .command('uninstall <toolset-id>')
  .description('Uninstall a specific ASDM toolset')
  .action(async (toolsetId: string) => {
    try {
      console.log(chalk.blue(`Uninstalling toolset: ${toolsetId}...`));

      // Check if installed
      if (!isToolsetInstalled(toolsetId)) {
        console.log(chalk.yellow(`Toolset '${toolsetId}' is not installed.`));
        console.log(chalk.gray('Run "asdm toolset list" to see installed toolsets.'));
        return;
      }

      const installPath = getToolsetInstallPath(toolsetId);

      // Remove toolset
      console.log(chalk.blue('Removing files...'));
      removeToolset(toolsetId);

      console.log(chalk.green(`✓ Successfully uninstalled '${toolsetId}'`));
      console.log(chalk.gray(`Removed from: ${installPath}`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// ==================== SPEC COMMANDS ====================

// Create spec subcommand
const specCommand = program
  .command('spec')
  .description('Spec management commands');

// Spec list command
specCommand
  .command('list')
  .description('List all available ASDM specs')
  .action(async () => {
    try {
      console.log(chalk.blue('Fetching available ASDM specs...'));
      const { SPECS_REGISTRY_URL } = await import('./config');
      console.log(chalk.gray(`Registry URL: ${SPECS_REGISTRY_URL}`));

      const registry = await fetchSpecsRegistry();

      console.log(chalk.green(`\nAvailable specs (Registry version: ${registry.version}):\n`));

      if (registry.specs.length === 0) {
        console.log(chalk.yellow('No specs available.'));
        return;
      }

      // Create table
      const table = new Table({
        head: [
          chalk.cyan.bold('Status'),
          chalk.cyan.bold('ID'),
          chalk.cyan.bold('Version'),
          chalk.cyan.bold('Name'),
          chalk.cyan.bold('Description')
        ],
        colWidths: [15, 35, 10, 35, 50],
        wordWrap: true
      });

      registry.specs.forEach((spec) => {
        const installed = isSpecInstalled(spec.id);
        const status = installed ? chalk.green('✓ Installed') : chalk.gray('○ Available');

        table.push([
          status,
          chalk.bold(spec.id),
          spec.version,
          spec.name,
          spec.description
        ]);
      });

      console.log(table.toString());
      console.log(chalk.gray(`\nTotal: ${registry.specs.length} specs`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// Spec install command
specCommand
  .command('install <spec-id>')
  .description('Download and install a specific ASDM spec')
  .action(async (specId: string) => {
    try {
      console.log(chalk.blue(`Installing spec: ${specId}...`));

      // Check if already installed
      if (isSpecInstalled(specId)) {
        console.log(chalk.yellow(`Spec '${specId}' is already installed.`));
        console.log(chalk.gray(`Location: ${getSpecInstallPath(specId)}`));
        return;
      }

      // Fetch registry to validate spec exists
      console.log(chalk.blue('Fetching registry...'));
      const registry = await fetchSpecsRegistry();
      const spec = registry.specs.find(s => s.id === specId);

      if (!spec) {
        console.error(chalk.red(`Error: Spec '${specId}' not found in registry.`));
        console.log(chalk.gray('Run "asdm spec list" to see available specs.'));
        process.exit(1);
      }

      // Download spec
      console.log(chalk.blue(`Downloading ${spec.name} (v${spec.version})...`));
      const downloadResult = await downloadSpec(specId, spec.downloadUrl);
      console.log(chalk.gray(`  Downloading from: ${downloadResult.actualUrl}`));

      // Prepare installation directory
      const installPath = getSpecInstallPath(specId);
      ensureDirectoryExists(installPath);

      // Extract spec
      console.log(chalk.blue('Extracting files...'));
      extractZip(downloadResult.buffer, installPath);

      console.log(chalk.green(`✓ Successfully installed '${specId}'`));
      console.log(chalk.gray(`Location: ${installPath}`));
    } catch (error) {
      console.log(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// Spec update command
specCommand
  .command('update <spec-id>')
  .description('Update a specific ASDM spec')
  .action(async (specId: string) => {
    try {
      console.log(chalk.blue(`Updating spec: ${specId}...`));

      // Check if installed
      if (!isSpecInstalled(specId)) {
        console.log(chalk.yellow(`Spec '${specId}' is not installed.`));
        console.log(chalk.gray('Run "asdm spec install <spec-id>" to install it first.'));
        return;
      }

      // Remove old version
      console.log(chalk.blue('Removing old version...'));
      removeSpec(specId);

      // Fetch registry to get latest version
      console.log(chalk.blue('Fetching latest version...'));
      const registry = await fetchSpecsRegistry();
      const spec = registry.specs.find(s => s.id === specId);

      if (!spec) {
        console.error(chalk.red(`Error: Spec '${specId}' not found in registry.`));
        process.exit(1);
      }

      // Download and install new version
      console.log(chalk.blue(`Downloading ${spec.name} (v${spec.version})...`));
      const downloadResult = await downloadSpec(specId, spec.downloadUrl);

      const installPath = getSpecInstallPath(specId);
      ensureDirectoryExists(installPath);

      console.log(chalk.blue('Extracting files...'));
      extractZip(downloadResult.buffer, installPath);

      console.log(chalk.green(`✓ Successfully updated '${specId}' to v${spec.version}`));
      console.log(chalk.gray(`Location: ${installPath}`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// Spec uninstall command
specCommand
  .command('uninstall <spec-id>')
  .description('Uninstall a specific ASDM spec')
  .action(async (specId: string) => {
    try {
      console.log(chalk.blue(`Uninstalling spec: ${specId}...`));

      // Check if installed
      if (!isSpecInstalled(specId)) {
        console.log(chalk.yellow(`Spec '${specId}' is not installed.`));
        console.log(chalk.gray('Run "asdm spec list" to see installed specs.'));
        return;
      }

      const installPath = getSpecInstallPath(specId);

      // Remove spec
      console.log(chalk.blue('Removing files...'));
      removeSpec(specId);

      console.log(chalk.green(`✓ Successfully uninstalled '${specId}'`));
      console.log(chalk.gray(`Removed from: ${installPath}`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// ==================== CONTEXT COMMANDS ====================

// Create context subcommand
const contextCommand = program
  .command('context')
  .description('Context management commands');

// Context list command
contextCommand
  .command('list')
  .description('List all available ASDM contexts')
  .action(async () => {
    try {
      console.log(chalk.blue('Fetching available ASDM contexts...'));
      const { CONTEXTS_REGISTRY_URL } = await import('./config');

      if (!CONTEXTS_REGISTRY_URL) {
        console.log(chalk.yellow('Contexts registry is not configured yet.'));
        console.log(chalk.gray('This feature will be available in a future release.'));
        return;
      }

      console.log(chalk.gray(`Registry URL: ${CONTEXTS_REGISTRY_URL}`));

      const registry = await fetchContextsRegistry();

      console.log(chalk.green(`\nAvailable contexts (Registry version: ${registry.version}):\n`));

      if (registry.contexts.length === 0) {
        console.log(chalk.yellow('No contexts available.'));
        return;
      }

      registry.contexts.forEach((context) => {
        const installed = isContextInstalled(context.id);
        const status = installed ? chalk.green('[INSTALLED]') : chalk.gray('[NOT INSTALLED]');

        console.log(`${status} ${chalk.bold(context.id)} (v${context.version})`);
        console.log(`  ${chalk.cyan(context.name)}`);
        console.log(`  ${context.description}`);
        console.log(`  ${chalk.gray('Download URL:')} ${context.downloadUrl}`);
        console.log('');
      });
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// Context install command
contextCommand
  .command('install <context-id>')
  .description('Download and install a specific ASDM context')
  .action(async (contextId: string) => {
    try {
      console.log(chalk.blue(`Installing context: ${contextId}...`));

      const { CONTEXTS_REGISTRY_URL } = await import('./config');

      if (!CONTEXTS_REGISTRY_URL) {
        console.log(chalk.yellow('Contexts registry is not configured yet.'));
        console.log(chalk.gray('This feature will be available in a future release.'));
        return;
      }

      // Check if already installed
      if (isContextInstalled(contextId)) {
        console.log(chalk.yellow(`Context '${contextId}' is already installed.`));
        console.log(chalk.gray(`Location: ${getContextInstallPath(contextId)}`));
        return;
      }

      // Fetch registry to validate context exists
      console.log(chalk.blue('Fetching registry...'));
      const registry = await fetchContextsRegistry();
      const context = registry.contexts.find(c => c.id === contextId);

      if (!context) {
        console.error(chalk.red(`Error: Context '${contextId}' not found in registry.`));
        console.log(chalk.gray('Run "asdm context list" to see available contexts.'));
        process.exit(1);
      }

      // Download context
      console.log(chalk.blue(`Downloading ${context.name} (v${context.version})...`));
      const downloadResult = await downloadContext(contextId, context.downloadUrl);
      console.log(chalk.gray(`  Downloading from: ${downloadResult.actualUrl}`));

      // Prepare installation directory
      const installPath = getContextInstallPath(contextId);
      ensureDirectoryExists(installPath);

      // Extract context
      console.log(chalk.blue('Extracting files...'));
      extractZip(downloadResult.buffer, installPath);

      console.log(chalk.green(`✓ Successfully installed '${contextId}'`));
      console.log(chalk.gray(`Location: ${installPath}`));
    } catch (error) {
      console.log(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// Context update command
contextCommand
  .command('update <context-id>')
  .description('Update a specific ASDM context')
  .action(async (contextId: string) => {
    try {
      console.log(chalk.blue(`Updating context: ${contextId}...`));

      const { CONTEXTS_REGISTRY_URL } = await import('./config');

      if (!CONTEXTS_REGISTRY_URL) {
        console.log(chalk.yellow('Contexts registry is not configured yet.'));
        console.log(chalk.gray('This feature will be available in a future release.'));
        return;
      }

      // Check if installed
      if (!isContextInstalled(contextId)) {
        console.log(chalk.yellow(`Context '${contextId}' is not installed.`));
        console.log(chalk.gray('Run "asdm context install <context-id>" to install it first.'));
        return;
      }

      // Remove old version
      console.log(chalk.blue('Removing old version...'));
      removeContext(contextId);

      // Fetch registry to get latest version
      console.log(chalk.blue('Fetching latest version...'));
      const registry = await fetchContextsRegistry();
      const context = registry.contexts.find(c => c.id === contextId);

      if (!context) {
        console.error(chalk.red(`Error: Context '${contextId}' not found in registry.`));
        process.exit(1);
      }

      // Download and install new version
      console.log(chalk.blue(`Downloading ${context.name} (v${context.version})...`));
      const downloadResult = await downloadContext(contextId, context.downloadUrl);

      const installPath = getContextInstallPath(contextId);
      ensureDirectoryExists(installPath);

      console.log(chalk.blue('Extracting files...'));
      extractZip(downloadResult.buffer, installPath);

      console.log(chalk.green(`✓ Successfully updated '${contextId}' to v${context.version}`));
      console.log(chalk.gray(`Location: ${installPath}`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// Context uninstall command
contextCommand
  .command('uninstall <context-id>')
  .description('Uninstall a specific ASDM context')
  .action(async (contextId: string) => {
    try {
      console.log(chalk.blue(`Uninstalling context: ${contextId}...`));

      const { CONTEXTS_REGISTRY_URL } = await import('./config');

      if (!CONTEXTS_REGISTRY_URL) {
        console.log(chalk.yellow('Contexts registry is not configured yet.'));
        console.log(chalk.gray('This feature will be available in a future release.'));
        return;
      }

      // Check if installed
      if (!isContextInstalled(contextId)) {
        console.log(chalk.yellow(`Context '${contextId}' is not installed.`));
        console.log(chalk.gray('Run "asdm context list" to see installed contexts.'));
        return;
      }

      const installPath = getContextInstallPath(contextId);

      // Remove context
      console.log(chalk.blue('Removing files...'));
      removeContext(contextId);

      console.log(chalk.green(`✓ Successfully uninstalled '${contextId}'`));
      console.log(chalk.gray(`Removed from: ${installPath}`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// ==================== SKILL COMMANDS ====================

// Create skill subcommand
const skillCommand = program
  .command('skill')
  .description('Skill management commands');

// Skill list command
skillCommand
  .command('list')
  .description('List all available ASDM skills')
  .action(async () => {
    try {
      console.log(chalk.blue('Fetching available ASDM skills...'));
      const { SKILLS_REGISTRY_URL } = await import('./config');
      console.log(chalk.gray(`Registry URL: ${SKILLS_REGISTRY_URL}`));

      const registry = await fetchSkillsRegistry();

      console.log(chalk.green(`\nAvailable skills (Registry version: ${registry.version}):\n`));

      if (registry.skills.length === 0) {
        console.log(chalk.yellow('No skills available.'));
        return;
      }

      // Create table
      const table = new Table({
        head: [
          chalk.cyan.bold('Status'),
          chalk.cyan.bold('ID'),
          chalk.cyan.bold('Version'),
          chalk.cyan.bold('Name'),
          chalk.cyan.bold('Description')
        ],
        colWidths: [15, 35, 10, 35, 50],
        wordWrap: true
      });

      registry.skills.forEach((skill) => {
        const installed = isSkillInstalled(skill.id);
        const status = installed ? chalk.green('✓ Installed') : chalk.gray('○ Available');

        table.push([
          status,
          chalk.bold(skill.id),
          skill.version,
          skill.name,
          skill.description
        ]);
      });

      console.log(table.toString());
      console.log(chalk.gray(`\nTotal: ${registry.skills.length} skills`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// ==================== WORKSPACE COMMANDS ====================

const workspaceCommand = program
  .command('workspace')
  .description(t('工作区管理命令', 'Workspace management commands'));

workspaceCommand
  .command('current')
  .description(t('显示当前工作区（activeWorkspaceId）', 'Show the active workspace (activeWorkspaceId)'))
  .action(() => {
    const state = readWorkspaceInstallsState();
    const id = state.activeWorkspaceId;
    if (id) {
      console.log(
        chalk.green(
          t(`当前工作区：${id}`, `Active workspace: ${id}`)
        )
      );
    } else {
      console.log(
        chalk.yellow(
          t(
            '当前未设置工作区（尚无 activeWorkspaceId）。可先执行 asdm workspace install <id> 再 asdm workspace switch <id>。',
            'No active workspace set (no activeWorkspaceId). Run "asdm workspace install <id>" then "asdm workspace switch <id>".'
          )
        )
      );
    }
  });

workspaceCommand
  .command('switch <workspace-id>')
  .description(
    t(
      '切换当前工作区；CodeBuddy 默认只显示该工作区（可用 workspace codebuddy 再并入其它）',
      'Set active workspace; CodeBuddy defaults to this workspace (use `workspace codebuddy` to merge more)'
    )
  )
  .action((workspaceId: string) => {
    try {
      switchWorkspace(workspaceId);
    } catch (err) {
      if (err instanceof WorkspaceNotInstalledError) {
        const id = err.workspaceId;
        const known = Object.keys(readWorkspaceInstallsState().workspaces);
        const hint =
          known.length > 0
            ? t(`已登记的工作区：${known.join('、')}`, `Known workspaces: ${known.join(', ')}`)
            : t('当前无任何已安装工作区。', 'No workspace installs recorded.');
        console.error(
          chalk.red(
            t(
              `错误：工作区「${id}」不存在或未执行过 install，无法切换。请先运行 asdm workspace install ${id}。`,
              `Error: Workspace "${id}" is not installed — cannot switch. Run "asdm workspace install ${id}" first.`
            )
          )
        );
        console.error(chalk.gray(hint));
        process.exit(1);
        return;
      }
      throw err;
    }
    const state = readWorkspaceInstallsState();
    syncCodeBuddyWorkspaceInstallsState(state);
    syncAsdmReadme();
    console.log(
      chalk.green(
        t(
          `✓ 当前工作区已设为「${workspaceId}」；CodeBuddy 合并列表已重置为仅该工作区。`,
          `✓ Active workspace is "${workspaceId}"; CodeBuddy merge list reset to this workspace only.`
        )
      )
    );
  });

const workspaceCodebuddyCommand = workspaceCommand
  .command('codebuddy')
  .description(
    t(
      '管理哪些工作区并入 CodeBuddy 斜杠指令（可多选，与当前工作区隔离的安装目录互不影响）',
      'Choose workspace(s) merged into CodeBuddy slash commands (install dirs stay isolated per workspace)'
    )
  );

workspaceCodebuddyCommand
  .command('list')
  .description(t('列出当前工作区与 CodeBuddy 合并列表', 'Show active workspace and CodeBuddy merge list'))
  .action(() => {
    const state = readWorkspaceInstallsState();
    const resolved = getResolvedCodeBuddyWorkspaceIds(state);
    console.log(
      chalk.blue(
        `${t('当前工作区', 'Active workspace')}: ${state.activeWorkspaceId ?? t('未设置', 'not set')}`
      )
    );
    console.log(
      chalk.blue(
        t(
          `已保存的合并列表: ${state.codeBuddyWorkspaceIds.length ? state.codeBuddyWorkspaceIds.join(', ') : t('（空则回退到仅 active）', '(empty → active only)')}`,
          `Saved merge list: ${state.codeBuddyWorkspaceIds.length ? state.codeBuddyWorkspaceIds.join(', ') : '(empty → active only)'}`
        )
      )
    );
    console.log(
      chalk.green(
        t(`实际生成 CodeBuddy 索引的工作区: ${resolved.length ? resolved.join(', ') : '（无）'}`, `Resolved for CodeBuddy: ${resolved.length ? resolved.join(', ') : '(none)'}`)
      )
    );
  });

workspaceCodebuddyCommand
  .command('add <workspace-id>')
  .description(t('把一个工作区加入 CodeBuddy 合并列表', 'Add a workspace to the CodeBuddy merge list'))
  .action((workspaceId: string) => {
    addCodeBuddyWorkspace(workspaceId);
    const state = readWorkspaceInstallsState();
    syncCodeBuddyWorkspaceInstallsState(state);
    syncAsdmReadme();
    console.log(chalk.green(t(`✓ 已加入「${workspaceId}」`, `✓ Added "${workspaceId}"`)));
  });

workspaceCodebuddyCommand
  .command('remove <workspace-id>')
  .description(t('从 CodeBuddy 合并列表移除', 'Remove a workspace from the CodeBuddy merge list'))
  .action((workspaceId: string) => {
    removeCodeBuddyWorkspaceEntry(workspaceId);
    const state = readWorkspaceInstallsState();
    syncCodeBuddyWorkspaceInstallsState(state);
    syncAsdmReadme();
    console.log(chalk.green(t(`✓ 已移除「${workspaceId}」`, `✓ Removed "${workspaceId}"`)));
  });

workspaceCodebuddyCommand
  .command('only')
  .description(t('仅合并指定的一个或多个工作区（覆盖当前合并列表）', 'Merge only these workspace(s) into CodeBuddy (replaces merge list)'))
  .argument('<ids...>', 'workspace id(s)')
  .action((ids: string[]) => {
    if (!ids || ids.length === 0) {
      console.log(chalk.yellow(t('请提供至少一个 workspace-id。', 'Pass at least one workspace id.')));
      return;
    }
    setCodeBuddyWorkspacesOnly(ids);
    const state = readWorkspaceInstallsState();
    syncCodeBuddyWorkspaceInstallsState(state);
    syncAsdmReadme();
    console.log(chalk.green(t(`✓ CodeBuddy 合并列表已设为: ${ids.join(', ')}`, `✓ CodeBuddy merge list set to: ${ids.join(', ')}`)));
  });

workspaceCodebuddyCommand
  .command('reset')
  .description(t('合并列表重置为仅当前工作区（与 switch 后默认一致）', 'Reset merge list to active workspace only (same as after switch)'))
  .action(() => {
    resetCodeBuddyWorkspacesToActive();
    const state = readWorkspaceInstallsState();
    syncCodeBuddyWorkspaceInstallsState(state);
    syncAsdmReadme();
    console.log(chalk.green(t('✓ 已重置为仅当前工作区', '✓ Reset to active workspace only')));
  });

const workspaceToolsetCommand = workspaceCommand
  .command('toolset')
  .description(t('工作区 toolset 子命令', 'Workspace toolset subcommands'));

workspaceToolsetCommand
  .command('list <workspace-id>')
  .description(t('列出工作区所需 toolset', 'List workspace required toolsets'))
  .option('-u, --url <registry-url>', t('覆盖工作区 API 地址（或使用 "mock"）', 'Override workspace registry URL (or use "mock")'))
  .action(async (workspaceId: string, options: { url?: string }) => {
    try {
      console.log(chalk.blue(t(`正在获取工作区所需 toolset（workspaceId: ${workspaceId}）...`, `Fetching workspace required toolsets (workspaceId: ${workspaceId})...`)));
      const registry = await fetchWorkspaceResourcesManifest(workspaceId, options.url);

      if (registry.toolsets.length === 0) {
        console.log(chalk.yellow(t('当前工作区没有可用 toolset。', 'No workspace toolsets found in registry response.')));
        return;
      }

      const table = buildWorkspaceToolsetsTable(registry);

      console.log(
        chalk.green(
          t(
            `\n工作区 toolsets（workspaceId: ${registry.workspaceId || workspaceId}, version: ${registry.version}）：\n`,
            `\nWorkspace toolsets (workspaceId: ${registry.workspaceId || workspaceId}, version: ${registry.version}):\n`
          )
        )
      );
      console.log(table.toString());
      console.log(chalk.gray(t(`\n共 ${registry.toolsets.length} 个 toolset`, `\nTotal: ${registry.toolsets.length} toolsets`)));
    } catch (error) {
      console.error(chalk.red(`${t('错误', 'Error')}: ${localizeWorkspaceError(error)}`));
      process.exit(1);
    }
  });

workspaceToolsetCommand
  .command('install <workspace-id> <toolset-id>')
  .description(
    t(
      '从工作区注册表安装单个 toolset 到 `.asdm/workspaces/<workspace-id>/toolsets/<id>/`（与工作区隔离）',
      'Install one workspace toolset under `.asdm/workspaces/<workspace-id>/toolsets/<id>/` (isolated per workspace)'
    )
  )
  .option('-u, --url <registry-url>', t('覆盖工作区 API 地址（或使用 "mock"）', 'Override workspace registry URL (or use "mock")'))
  .option('-f, --force', t('即使已安装也强制重装', 'Reinstall even if already installed'), false)
  .action(async (workspaceId: string, toolsetIdArg: string, options: { url?: string; force?: boolean }) => {
    try {
      const force = Boolean(options.force);
      console.log(
        chalk.blue(
          t(
            `正在安装工作区 toolset：${toolsetIdArg}（workspaceId: ${workspaceId}）...`,
            `Installing workspace toolset: ${toolsetIdArg} (workspaceId: ${workspaceId})...`
          )
        )
      );

      console.log(chalk.blue(t('正在获取工作区注册表...', 'Fetching workspace registry...')));
      const registry = await fetchWorkspaceResourcesManifest(workspaceId, options.url);

      const toolset = registry.toolsets.find((row) => row.id === toolsetIdArg || row.name === toolsetIdArg);
      if (!toolset) {
        console.error(chalk.red(t(`错误：工作区中未找到 toolset '${toolsetIdArg}'。`, `Error: Toolset '${toolsetIdArg}' not found in workspace registry.`)));
        console.log(
          chalk.gray(
            t(
              '运行 asdm workspace toolset list <workspace-id> 或 asdm workspace list <workspace-id> 查看可用 toolset。',
              'Run "asdm workspace toolset list <workspace-id>" or "asdm workspace list <workspace-id>" to see available toolsets.'
            )
          )
        );
        process.exit(1);
      }

      if (!toolset.downloadUrl) {
        console.error(chalk.red(t('错误：该 toolset 缺少 downloadUrl。', 'Error: Toolset record has no downloadUrl.')));
        process.exit(1);
      }

      const resolvedId = toolset.id;

      if (isWorkspaceToolsetInstalled(workspaceId, resolvedId) && !force) {
        console.log(chalk.yellow(t(`Toolset '${resolvedId}' 已安装。`, `Toolset '${resolvedId}' is already installed.`)));
        console.log(chalk.gray(`${t('路径', 'Location')}: ${getWorkspaceToolsetInstallPath(workspaceId, resolvedId)}`));
        return;
      }

      if (isWorkspaceToolsetInstalled(workspaceId, resolvedId) && force) {
        console.log(chalk.blue(t('正在移除旧版本...', 'Removing old version...')));
        removeWorkspaceScopedToolset(workspaceId, resolvedId);
      }

      const verStr = toolset.version ? ` (v${toolset.version})` : '';
      console.log(chalk.blue(t(`正在下载 ${toolset.name}${verStr}...`, `Downloading ${toolset.name}${verStr}...`)));
      const downloadResult = await downloadToolset(resolvedId, toolset.downloadUrl);
      console.log(chalk.gray(`  ${t('下载自', 'Downloading from')}: ${downloadResult.actualUrl}`));

      const installPath = getWorkspaceToolsetInstallPath(workspaceId, resolvedId);
      ensureDirectoryExists(installPath);

      console.log(chalk.blue(t('正在解压文件...', 'Extracting files...')));
      extractZip(downloadResult.buffer, installPath);

      addToolsetToWorkspaceInstall(workspaceId, resolvedId);
      syncCodeBuddyWorkspaceInstallsState(readWorkspaceInstallsState());
      syncAsdmReadme();

      console.log(chalk.green(t(`✓ 已成功安装 '${resolvedId}'`, `✓ Successfully installed '${resolvedId}'`)));
      console.log(chalk.gray(`${t('路径', 'Location')}: ${installPath}`));

      const installMdPath = `${installPath}/INSTALL.md`;
      console.log(chalk.cyan(`\n📋 ${t('AI 模型说明', 'AI Model Instruction')}:`));
      console.log(chalk.white(`  follow instructions ${installMdPath}`));
    } catch (error) {
      console.error(chalk.red(`${t('错误', 'Error')}: ${localizeWorkspaceError(error)}`));
      process.exit(1);
    }
  });

workspaceToolsetCommand
  .command('update <workspace-id> <toolset-id>')
  .description(
    t(
      '按工作区注册表更新当前目录 .asdm 下已安装的 toolset（对齐 asdm toolset update）',
      'Update a workspace toolset installed under cwd `.asdm` (same idea as asdm toolset update)'
    )
  )
  .option('-u, --url <registry-url>', t('覆盖工作区 API 地址（或使用 "mock"）', 'Override workspace registry URL (or use "mock")'))
  .action(async (workspaceId: string, toolsetIdArg: string, options: { url?: string }) => {
    try {
      console.log(
        chalk.blue(
          t(
            `正在更新工作区 toolset：${toolsetIdArg}（workspaceId: ${workspaceId}）...`,
            `Updating workspace toolset: ${toolsetIdArg} (workspaceId: ${workspaceId})...`
          )
        )
      );

      console.log(chalk.blue(t('正在获取工作区注册表...', 'Fetching workspace registry...')));
      const registry = await fetchWorkspaceResourcesManifest(workspaceId, options.url);

      const toolset = registry.toolsets.find((row) => row.id === toolsetIdArg || row.name === toolsetIdArg);
      if (!toolset) {
        console.error(chalk.red(t(`错误：工作区中未找到 toolset '${toolsetIdArg}'。`, `Error: Toolset '${toolsetIdArg}' not found in workspace registry.`)));
        console.log(
          chalk.gray(
            t(
              '运行 asdm workspace toolset list <workspace-id> 或 asdm workspace list <workspace-id> 查看可用 toolset。',
              'Run "asdm workspace toolset list <workspace-id>" or "asdm workspace list <workspace-id>" to see available toolsets.'
            )
          )
        );
        process.exit(1);
      }

      if (!toolset.downloadUrl) {
        console.error(chalk.red(t('错误：该 toolset 缺少 downloadUrl。', 'Error: Toolset record has no downloadUrl.')));
        process.exit(1);
      }

      const resolvedId = toolset.id;

      if (!isWorkspaceToolsetInstalled(workspaceId, resolvedId)) {
        console.log(
          chalk.yellow(
            t(
              `Toolset '${resolvedId}' 未安装在该工作区沙箱下。`,
              `Toolset '${resolvedId}' is not installed under this workspace sandbox.`
            )
          )
        );
        console.log(
          chalk.gray(
            t(
              '运行 asdm workspace toolset install <workspace-id> <toolset-id> 先安装。',
              'Run "asdm workspace toolset install <workspace-id> <toolset-id>" to install it first.'
            )
          )
        );
        return;
      }

      console.log(chalk.blue(t('正在移除旧版本...', 'Removing old version...')));
      removeWorkspaceScopedToolset(workspaceId, resolvedId);

      const verStr = toolset.version ? ` (v${toolset.version})` : '';
      console.log(chalk.blue(t(`正在下载 ${toolset.name}${verStr}...`, `Downloading ${toolset.name}${verStr}...`)));
      const downloadResult = await downloadToolset(resolvedId, toolset.downloadUrl);
      console.log(chalk.gray(`  ${t('下载自', 'Downloading from')}: ${downloadResult.actualUrl}`));

      const installPath = getWorkspaceToolsetInstallPath(workspaceId, resolvedId);
      ensureDirectoryExists(installPath);

      console.log(chalk.blue(t('正在解压文件...', 'Extracting files...')));
      extractZip(downloadResult.buffer, installPath);

      addToolsetToWorkspaceInstall(workspaceId, resolvedId);
      syncCodeBuddyWorkspaceInstallsState(readWorkspaceInstallsState());
      syncAsdmReadme();

      console.log(
        chalk.green(
          t(`✓ 已更新 '${resolvedId}'${toolset.version ? ` 至 v${toolset.version}` : ''}`, `✓ Successfully updated '${resolvedId}'${toolset.version ? ` to v${toolset.version}` : ''}`)
        )
      );
      console.log(chalk.gray(`${t('路径', 'Location')}: ${installPath}`));
    } catch (error) {
      console.error(chalk.red(`${t('错误', 'Error')}: ${localizeWorkspaceError(error)}`));
      process.exit(1);
    }
  });

workspaceToolsetCommand
  .command('uninstall <workspace-id> <toolset-id>')
  .description(
    t(
      '从该工作区沙箱 `.asdm/workspaces/<id>/toolsets/` 卸载单个 toolset',
      'Uninstall one toolset from this workspace sandbox under `.asdm/workspaces/<id>/toolsets/`'
    )
  )
  .option('-u, --url <registry-url>', t('覆盖工作区 API 地址（或使用 "mock"）', 'Override workspace registry URL (or use "mock")'))
  .action(async (workspaceId: string, toolsetIdArg: string, options: { url?: string }) => {
    try {
      console.log(
        chalk.blue(
          t(
            `正在卸载工作区 toolset：${toolsetIdArg}（workspaceId: ${workspaceId}）...`,
            `Uninstalling workspace toolset: ${toolsetIdArg} (workspaceId: ${workspaceId})...`
          )
        )
      );

      console.log(chalk.blue(t('正在获取工作区注册表...', 'Fetching workspace registry...')));
      const registry = await fetchWorkspaceResourcesManifest(workspaceId, options.url);

      const toolset = registry.toolsets.find((row) => row.id === toolsetIdArg || row.name === toolsetIdArg);
      if (!toolset) {
        console.error(chalk.red(t(`错误：工作区中未找到 toolset '${toolsetIdArg}'。`, `Error: Toolset '${toolsetIdArg}' not found in workspace registry.`)));
        console.log(
          chalk.gray(
            t(
              '运行 asdm workspace toolset list <workspace-id> 或 asdm workspace list <workspace-id> 查看可用 toolset。',
              'Run "asdm workspace toolset list <workspace-id>" or "asdm workspace list <workspace-id>" to see available toolsets.'
            )
          )
        );
        process.exit(1);
      }

      const resolvedId = toolset.id;

      if (!isWorkspaceToolsetInstalled(workspaceId, resolvedId)) {
        console.log(
          chalk.yellow(
            t(
              `Toolset '${resolvedId}' 未安装在该工作区沙箱下。`,
              `Toolset '${resolvedId}' is not installed under this workspace sandbox.`
            )
          )
        );
        console.log(
          chalk.gray(
            t(
              '运行 asdm workspace toolset list <workspace-id> 查看该工作区 toolset 列表。',
              'Run "asdm workspace toolset list <workspace-id>" to list required toolsets.'
            )
          )
        );
        return;
      }

      const installPath = getWorkspaceToolsetInstallPath(workspaceId, resolvedId);

      removeToolsetFromWorkspaceInstall(workspaceId, resolvedId);
      console.log(chalk.blue(t('正在删除文件...', 'Removing files...')));
      removeWorkspaceScopedToolset(workspaceId, resolvedId);

      const stateAfter = readWorkspaceInstallsState();
      syncCodeBuddyWorkspaceInstallsState(stateAfter);
      syncAsdmReadme();

      console.log(chalk.green(t(`✓ 已卸载 '${resolvedId}'`, `✓ Successfully uninstalled '${resolvedId}'`)));
      console.log(chalk.gray(`${t('已从以下路径移除', 'Removed from')}: ${installPath}`));
    } catch (error) {
      console.error(chalk.red(`${t('错误', 'Error')}: ${localizeWorkspaceError(error)}`));
      process.exit(1);
    }
  });

workspaceCommand
  .command('list <workspace-id>')
  .description(t('查看工作区所需的所有 toolset', 'List all toolsets required by workspace'))
  .option('-u, --url <registry-url>', t('覆盖工作区 API 地址（或使用 "mock"）', 'Override workspace registry URL (or use "mock")'))
  .action(async (workspaceId: string, options: { url?: string }) => {
    try {
      console.log(chalk.blue(t(`正在获取工作区资源（workspaceId: ${workspaceId}）...`, `Fetching workspace resources (workspaceId: ${workspaceId})...`)));
      const registry = await fetchWorkspaceResourcesManifest(workspaceId, options.url);

      const hasToolsets = (registry.toolsets || []).length > 0;
      const hasSpecs = (registry.specs || []).length > 0;
      const hasContexts = (registry.contexts || []).length > 0;

      if (!hasToolsets && !hasSpecs && !hasContexts) {
        console.log(chalk.yellow(t('当前工作区没有可用资源。', 'No workspace resources found.')));
        return;
      }

      console.log(chalk.green(t(
        `\n工作区资源（workspaceId: ${registry.workspaceId || workspaceId}, version: ${registry.version}）：`,
        `\nWorkspace resources (workspaceId: ${registry.workspaceId || workspaceId}, version: ${registry.version}):`
      )));

      if (hasToolsets) {
        console.log(chalk.cyan.bold(`\n  Toolsets (${registry.toolsets.length})`));
        const table = new Table({
          head: [chalk.cyan.bold(t('名称', 'Name')), chalk.cyan.bold(t('描述', 'Description'))],
          wordWrap: true
        });
        registry.toolsets.forEach((ts) => table.push([ts.name, ts.description || '—']));
        console.log(table.toString());
      }

      if (hasSpecs) {
        console.log(chalk.cyan.bold(`\n  Specs (${registry.specs!.length})`));
        const table = new Table({
          head: [chalk.cyan.bold(t('名称', 'Name')), chalk.cyan.bold(t('描述', 'Description'))],
          wordWrap: true
        });
        registry.specs!.forEach((sp) => table.push([sp.name, sp.description || '—']));
        console.log(table.toString());
      }

      if (hasContexts) {
        console.log(chalk.cyan.bold(`\n  Contexts (${registry.contexts!.length})`));
        const table = new Table({
          head: [chalk.cyan.bold(t('名称', 'Name')), chalk.cyan.bold(t('描述', 'Description'))],
          wordWrap: true
        });
        registry.contexts!.forEach((ctx) => table.push([ctx.name, ctx.description || '—']));
        console.log(table.toString());
      }

      const total = (registry.toolsets || []).length + (registry.specs || []).length + (registry.contexts || []).length;
      console.log(chalk.gray(t(`\n共 ${total} 个资源`, `\nTotal: ${total} resources`)));
    } catch (error) {
      console.error(chalk.red(`${t('错误', 'Error')}: ${localizeWorkspaceError(error)}`));
      process.exit(1);
    }
  });

workspaceCommand
  .command('install <workspace-id>')
  .description(
    t(
      '按工作区安装到 `.asdm/workspaces/<id>/`（与其它工作区隔离）；登记写入 workspace-installs.json',
      'Install all toolsets/specs under `.asdm/workspaces/<id>/` (isolated); manifest in workspace-installs.json'
    )
  )
  .option('-u, --url <registry-url>', t('覆盖工作区 API 地址（或使用 "mock"）', 'Override workspace registry URL (or use "mock")'))
  .option('-f, --force', t('日志中标为强制重装（默认已对已存在 id 覆盖安装）', 'Mark logs as force reinstall (default already overwrites existing ids)'), false)
  .action(async (workspaceId: string, options: { url?: string; force?: boolean }) => {
    try {
      const forceReinstall = Boolean(options.force);

      console.log(
        chalk.blue(
          t(
            `正在获取工作区注册表（workspaceId: ${workspaceId}）...`,
            `Fetching workspace registry (workspaceId: ${workspaceId})...`
          )
        )
      );
      const registry = await fetchWorkspaceResourcesManifest(workspaceId, options.url);

      const targetToolsets = registry.toolsets;
      const targetSpecs = registry.specs ?? [];
      const targetContexts = registry.contexts ?? [];
      if (targetToolsets.length === 0 && targetSpecs.length === 0 && targetContexts.length === 0) {
        console.log(chalk.yellow(t('当前工作区没有可用的 toolset、spec 或 context。', 'No workspace toolsets, specs or contexts in registry response.')));
        return;
      }

      const intendedIds = targetToolsets.filter((t) => t.id).map((t) => t.id);
      const intendedSpecIds = targetSpecs.filter((s) => s.id).map((s) => s.id);
      const intendedContextIds = targetContexts.filter((c) => c.id).map((c) => c.id);

      const { droppedToolsetIds, droppedSpecIds, droppedContextIds } = upsertWorkspaceInstallManifest(
        workspaceId,
        intendedIds,
        intendedSpecIds,
        intendedContextIds,
        registry.version
      );
      pruneDroppedWorkspaceResources(workspaceId, droppedToolsetIds, droppedSpecIds, droppedContextIds);

      console.log(
        chalk.gray(
          t(
            `目标：${join(LOCAL_ASDM_DIR, 'workspaces', workspaceId, 'toolsets')}/、${join(LOCAL_ASDM_DIR, 'workspaces', workspaceId, 'specs')}/、${join(LOCAL_ASDM_DIR, 'workspaces', workspaceId, 'contexts')}/，以及 ${join(LOCAL_ASDM_DIR, WORKSPACE_INSTALLS_FILE)}、.codebuddy/commands/`,
            `Targets: ${join(LOCAL_ASDM_DIR, 'workspaces', workspaceId, 'toolsets')}/, ${join(LOCAL_ASDM_DIR, 'workspaces', workspaceId, 'specs')}/, ${join(LOCAL_ASDM_DIR, 'workspaces', workspaceId, 'contexts')}/, ${join(LOCAL_ASDM_DIR, WORKSPACE_INSTALLS_FILE)}, .codebuddy/commands/`
          )
        )
      );
      console.log(chalk.gray(`${t('说明', 'Note')}: ${join(LOCAL_ASDM_DIR, 'README.md')}`));
      console.log(
        chalk.green(
          t(
            `将处理 ${targetToolsets.length} 个 toolset、${targetSpecs.length} 个 spec、${targetContexts.length} 个 context。\n`,
            `Will process ${targetToolsets.length} toolset(s), ${targetSpecs.length} spec(s), ${targetContexts.length} context(s).\n`
          )
        )
      );

      let installedCount = 0;
      let skippedCount = 0;
      let failedCount = 0;
      const failedToolsets: string[] = [];
      const failedSpecs: string[] = [];
      const failedContexts: string[] = [];

      for (const toolset of targetToolsets) {
        if (!toolset.id) {
          console.log(chalk.yellow(`Skipping invalid toolset record: ${JSON.stringify(toolset)}`));
          skippedCount += 1;
          continue;
        }


        const installPath = getWorkspaceToolsetInstallPath(workspaceId, toolset.id);
        const alreadyInstalled = isWorkspaceToolsetInstalled(workspaceId, toolset.id);

        if (alreadyInstalled) {
          console.log(
            chalk.blue(
              forceReinstall
                ? t(`正在强制重装 '${toolset.id}'...`, `Force reinstalling '${toolset.id}'...`)
                : t(`正在覆盖安装 '${toolset.id}'...`, `Overwriting '${toolset.id}'...`)
            )
          );
          removeWorkspaceScopedToolset(workspaceId, toolset.id);
        } else {
          console.log(chalk.blue(t(`正在安装 '${toolset.id}'...`, `Installing '${toolset.id}'...`)));
        }

        try {
          const downloadResult = await downloadToolset(toolset.id, toolset.downloadUrl);
          ensureDirectoryExists(installPath);
          extractZip(downloadResult.buffer, installPath);

          console.log(chalk.green(t(`✓ 已安装 '${toolset.id}'`, `✓ Installed '${toolset.id}'`)));
          console.log(chalk.gray(`  ${installPath}`));
          installedCount += 1;
        } catch (error) {
          console.log(chalk.red(t(`✗ 安装失败 '${toolset.id}': ${error instanceof Error ? error.message : '未知错误'}`, `✗ Failed '${toolset.id}': ${error instanceof Error ? error.message : 'Unknown error'}`)));
          failedCount += 1;
          failedToolsets.push(toolset.id);
        }
      }

      for (const spec of targetSpecs) {
        if (!spec.id) {
          console.log(chalk.yellow(`Skipping invalid spec record: ${JSON.stringify(spec)}`));
          skippedCount += 1;
          continue;
        }


        const installPath = getWorkspaceSpecInstallPath(workspaceId, spec.id);
        const alreadyInstalled = isWorkspaceSpecInstalled(workspaceId, spec.id);

        if (alreadyInstalled) {
          console.log(
            chalk.blue(
              forceReinstall
                ? t(`正在强制重装 spec '${spec.id}'...`, `Force reinstalling spec '${spec.id}'...`)
                : t(`正在覆盖安装 spec '${spec.id}'...`, `Overwriting spec '${spec.id}'...`)
            )
          );
          removeWorkspaceScopedSpec(workspaceId, spec.id);
        } else {
          console.log(chalk.blue(t(`正在安装 spec '${spec.id}'...`, `Installing spec '${spec.id}'...`)));
        }

        try {
          const downloadResult = await downloadSpec(spec.id, spec.downloadUrl);
          ensureDirectoryExists(installPath);
          extractZip(downloadResult.buffer, installPath);

          console.log(chalk.green(t(`✓ 已安装 spec '${spec.id}'`, `✓ Installed spec '${spec.id}'`)));
          console.log(chalk.gray(`  ${installPath}`));
          installedCount += 1;
        } catch (error) {
          console.log(chalk.red(t(`✗ spec 安装失败 '${spec.id}': ${error instanceof Error ? error.message : '未知错误'}`, `✗ Failed spec '${spec.id}': ${error instanceof Error ? error.message : 'Unknown error'}`)));
          failedCount += 1;
          failedSpecs.push(spec.id);
        }
      }

      if (targetContexts.length > 0) {
        console.log(chalk.blue(t('正在获取 context 内容...', 'Fetching context content...')));
        try {
          const contextResults = await fetchLatestContextResults(workspaceId);
          const resultMap = new Map(contextResults.map((r) => [r.contextId, r]));
          for (const ctx of targetContexts) {
            if (!ctx.id) {
              skippedCount += 1;
              continue;
            }
            const result = resultMap.get(ctx.id);
            if (!result) {
              console.log(chalk.yellow(t(`⚠ context '${ctx.id}' 未获取到内容`, `⚠ No content for context '${ctx.id}'`)));
              failedCount += 1;
              failedContexts.push(ctx.id);
              continue;
            }
            const dirName = result.contextName ? `${result.contextName}_${ctx.id}` : ctx.id;
            const installDir = join(process.cwd(), LOCAL_ASDM_DIR, 'workspaces', workspaceId, 'contexts', dirName);
            if (isWorkspaceContextInstalled(workspaceId, ctx.id)) {
              removeWorkspaceScopedContext(workspaceId, ctx.id);
            }
            installWorkspaceContextContent(workspaceId, ctx.id, result.contextName, result.fileName, result.fileContent);
            console.log(chalk.green(t(`✓ 已安装 context '${ctx.id}'`, `✓ Installed context '${ctx.id}'`)));
            console.log(chalk.gray(`  ${join(installDir, result.fileName)}`));
            installedCount += 1;
          }
        } catch (error) {
          console.log(chalk.red(t(`✗ context 内容获取失败: ${error instanceof Error ? error.message : '未知错误'}`, `✗ Failed to fetch context content: ${error instanceof Error ? error.message : 'Unknown error'}`)));
          failedCount += targetContexts.length;
          targetContexts.forEach((c) => { if (c.id) failedContexts.push(c.id); });
        }
      }

      syncCodeBuddyWorkspaceInstallsState(readWorkspaceInstallsState());
      syncAsdmReadme();

      console.log(chalk.green(t('\n工作区安装完成。', '\nWorkspace installation completed.')));
      console.log(
        chalk.gray(
          t(
            `已更新 ${join(LOCAL_ASDM_DIR, WORKSPACE_INSTALLS_FILE)}、.codebuddy/commands/、${join(LOCAL_ASDM_DIR, 'README.md')}。`,
            `Updated ${join(LOCAL_ASDM_DIR, WORKSPACE_INSTALLS_FILE)}, .codebuddy/commands/, and ${join(LOCAL_ASDM_DIR, 'README.md')}.`
          )
        )
      );
      console.log(chalk.gray(t(`成功/跳过/失败（合计）: ${installedCount} / ${skippedCount} / ${failedCount}`, `OK / Skipped / Failed (total): ${installedCount} / ${skippedCount} / ${failedCount}`)));
      if (failedToolsets.length > 0) {
        console.log(chalk.yellow(t(`失败的 toolsets: ${failedToolsets.join(', ')}`, `Failed toolsets: ${failedToolsets.join(', ')}`)));
        process.exitCode = 1;
      }
      if (failedSpecs.length > 0) {
        console.log(chalk.yellow(t(`失败的 specs: ${failedSpecs.join(', ')}`, `Failed specs: ${failedSpecs.join(', ')}`)));
        process.exitCode = 1;
      }
      if (failedContexts.length > 0) {
        console.log(chalk.yellow(t(`失败的 contexts: ${failedContexts.join(', ')}`, `Failed contexts: ${failedContexts.join(', ')}`)));
        process.exitCode = 1;
      }
    } catch (error) {
      console.error(chalk.red(`${t('错误', 'Error')}: ${localizeWorkspaceError(error)}`));
      process.exit(1);
    }
  });

workspaceCommand
  .command('uninstall <workspace-id>')
  .description(
    t(
      '卸载该工作区：删除 `.asdm/workspaces/<id>/` 及 workspace-installs.json 中的登记',
      'Uninstall workspace: remove `.asdm/workspaces/<id>/` and its manifest entry'
    )
  )
  .action(async (workspaceId: string) => {
    try {
      const rec = removeWorkspaceInstallAndPruneDisk(workspaceId);
      if (!rec) {
        console.log(
          chalk.yellow(
            t(
              `未找到工作区「${workspaceId}」的安装记录（尚无对应条目或已卸载）。`,
              `No install record for workspace "${workspaceId}" (nothing to uninstall).`
            )
          )
        );
        return;
      }

      console.log(chalk.blue(t(`正在卸载工作区 '${workspaceId}'（沙箱目录与登记）...`, `Uninstalling workspace '${workspaceId}' (sandbox + manifest)...`)));
      syncCodeBuddyWorkspaceInstallsState(readWorkspaceInstallsState());
      syncAsdmReadme();

      console.log(
        chalk.green(
          t(
            `✓ 已移除工作区「${workspaceId}」及目录 .asdm/workspaces/${workspaceId}/（曾登记 ${rec.toolsetIds.length} 个 toolset、${rec.specIds.length} 个 spec）。`,
            `✓ Removed workspace "${workspaceId}" and .asdm/workspaces/${workspaceId}/ (${rec.toolsetIds.length} toolset(s), ${rec.specIds.length} spec(s) were recorded).`
          )
        )
      );
    } catch (error) {
      console.error(chalk.red(`${t('错误', 'Error')}: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// Skill install command
skillCommand
  .command('install <skill-id>')
  .description('Download and install a specific ASDM skill')
  .action(async (skillId: string) => {
    try {
      console.log(chalk.blue(`Installing skill: ${skillId}...`));

      // Check if already installed
      if (isSkillInstalled(skillId)) {
        console.log(chalk.yellow(`Skill '${skillId}' is already installed.`));
        console.log(chalk.gray(`Location: ${getSkillInstallPath(skillId)}`));
        return;
      }

      // Fetch registry to validate skill exists
      console.log(chalk.blue('Fetching registry...'));
      const registry = await fetchSkillsRegistry();
      const skill = registry.skills.find(s => s.id === skillId);

      if (!skill) {
        console.error(chalk.red(`Error: Skill '${skillId}' not found in registry.`));
        console.log(chalk.gray('Run "asdm skill list" to see available skills.'));
        process.exit(1);
      }

      // Download skill
      console.log(chalk.blue(`Downloading ${skill.name} (v${skill.version})...`));
      const downloadResult = await downloadSkill(skillId, skill.downloadUrl);
      console.log(chalk.gray(`  Downloading from: ${downloadResult.actualUrl}`));

      // Prepare installation directory
      const installPath = getSkillInstallPath(skillId);
      ensureDirectoryExists(installPath);

      // Extract skill
      console.log(chalk.blue('Extracting files...'));
      extractZip(downloadResult.buffer, installPath);

      console.log(chalk.green(`✓ Successfully installed '${skillId}'`));
      console.log(chalk.gray(`Location: ${installPath}`));

      // Output instruction for AI Model
      const installMdPath = `${installPath}/INSTALL.md`;
      console.log(chalk.cyan('\nAI Model Instruction:'));
      console.log(chalk.white(`  follow instructions ${installMdPath}`));
    } catch (error) {
      console.log(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// Skill update command
skillCommand
  .command('update <skill-id>')
  .description('Update a specific ASDM skill')
  .action(async (skillId: string) => {
    try {
      console.log(chalk.blue(`Updating skill: ${skillId}...`));

      // Check if installed
      if (!isSkillInstalled(skillId)) {
        console.log(chalk.yellow(`Skill '${skillId}' is not installed.`));
        console.log(chalk.gray('Run "asdm skill install <skill-id>" to install it first.'));
        return;
      }

      // Remove old version
      console.log(chalk.blue('Removing old version...'));
      removeSkill(skillId);

      // Fetch registry to get latest version
      console.log(chalk.blue('Fetching latest version...'));
      const registry = await fetchSkillsRegistry();
      const skill = registry.skills.find(s => s.id === skillId);

      if (!skill) {
        console.error(chalk.red(`Error: Skill '${skillId}' not found in registry.`));
        process.exit(1);
      }

      // Download and install new version
      console.log(chalk.blue(`Downloading ${skill.name} (v${skill.version})...`));
      const downloadResult = await downloadSkill(skillId, skill.downloadUrl);

      const installPath = getSkillInstallPath(skillId);
      ensureDirectoryExists(installPath);

      console.log(chalk.blue('Extracting files...'));
      extractZip(downloadResult.buffer, installPath);

      console.log(chalk.green(`✓ Successfully updated '${skillId}' to v${skill.version}`));
      console.log(chalk.gray(`Location: ${installPath}`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// Skill uninstall command
skillCommand
  .command('uninstall <skill-id>')
  .description('Uninstall a specific ASDM skill')
  .action(async (skillId: string) => {
    try {
      console.log(chalk.blue(`Uninstalling skill: ${skillId}...`));

      // Check if installed
      if (!isSkillInstalled(skillId)) {
        console.log(chalk.yellow(`Skill '${skillId}' is not installed.`));
        console.log(chalk.gray('Run "asdm skill list" to see installed skills.'));
        return;
      }

      const installPath = getSkillInstallPath(skillId);

      // Remove skill
      console.log(chalk.blue('Removing files...'));
      removeSkill(skillId);

      console.log(chalk.green(`✓ Successfully uninstalled '${skillId}'`));
      console.log(chalk.gray(`Removed from: ${installPath}`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`));
      process.exit(1);
    }
  });

// Default action when no command is provided
program.action(() => {
  program.help();
});

program.parse(process.argv);

// Show help if no arguments provided
if (process.argv.length === 2) {
  program.help();
}
