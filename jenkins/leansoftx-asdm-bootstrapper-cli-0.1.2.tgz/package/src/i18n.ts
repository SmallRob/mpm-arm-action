import { getLanguage } from './user-config';

export function t(cn: string, us: string): string {
  return getLanguage() === 'US' ? us : cn;
}
