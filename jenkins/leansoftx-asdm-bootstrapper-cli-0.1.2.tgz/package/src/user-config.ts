import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';

export type AsdmLanguage = 'CN' | 'US';

export interface AsdmUserConfig {
  language?: AsdmLanguage;
  baseUrl?: string;
  artifactBaseUrl?: string;
}

const ASDM_DIR = path.join(os.homedir(), '.asdm');
const CONFIG_PATH = path.join(ASDM_DIR, 'config.json');

export function getConfigPath(): string {
  return CONFIG_PATH;
}

export function normalizeLanguage(input: string): AsdmLanguage | null {
  const normalized = input.trim().toUpperCase();
  if (normalized === 'CN' || normalized === 'US') {
    return normalized;
  }
  return null;
}

export function readUserConfig(): AsdmUserConfig {
  try {
    if (!fs.existsSync(CONFIG_PATH)) {
      return {};
    }
    const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
    return JSON.parse(raw) as AsdmUserConfig;
  } catch {
    return {};
  }
}

export function ensureUserConfigWithDefaults(): void {
  if (!fs.existsSync(ASDM_DIR)) {
    fs.mkdirSync(ASDM_DIR, { recursive: true });
  }

  const config = readUserConfig();
  const merged: AsdmUserConfig = {
    language: config.language ?? 'CN',
    baseUrl: config.baseUrl ?? 'https://platform.asdm.ai',
    artifactBaseUrl: config.artifactBaseUrl ?? undefined
  };

  // Only write when something actually changes (avoid touching the file on every run).
  const changed =
    merged.language !== config.language ||
    merged.baseUrl !== config.baseUrl ||
    merged.artifactBaseUrl !== config.artifactBaseUrl;

  if (changed || !fs.existsSync(CONFIG_PATH)) {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(merged, null, 2), 'utf8');
  }
}

export function getLanguage(): AsdmLanguage {
  const config = readUserConfig();
  return config.language || 'CN';
}

export function getBaseUrlFromConfig(): string {
  const config = readUserConfig();
  return config.baseUrl || 'https://platform.asdm.ai';
}

export function writeLanguage(language: AsdmLanguage): void {
  if (!fs.existsSync(ASDM_DIR)) {
    fs.mkdirSync(ASDM_DIR, { recursive: true });
  }
  const config: AsdmUserConfig = readUserConfig();
  config.language = language;
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf8');
}

export function writeBaseUrl(baseUrl: string): void {
  if (!fs.existsSync(ASDM_DIR)) {
    fs.mkdirSync(ASDM_DIR, { recursive: true });
  }
  const config: AsdmUserConfig = readUserConfig();
  config.baseUrl = baseUrl;
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf8');
}

export function getArtifactBaseUrlFromConfig(): string {
  const config = readUserConfig();
  return config.artifactBaseUrl || '';
}

export function writeArtifactBaseUrl(url: string): void {
  if (!fs.existsSync(ASDM_DIR)) {
    fs.mkdirSync(ASDM_DIR, { recursive: true });
  }
  const config: AsdmUserConfig = readUserConfig();
  config.artifactBaseUrl = url;
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf8');
}

